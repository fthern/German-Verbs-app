CREATE TABLE sets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category TEXT NOT NULL,
  progress REAL DEFAULT 0,
  created_at TEXT NOT NULL
) STRICT;

CREATE TABLE cards (
  id TEXT PRIMARY KEY,
  set_id TEXT NOT NULL,
  term TEXT NOT NULL,
  type TEXT NOT NULL,
  translation TEXT NOT NULL,
  details TEXT,
  secondary_meanings TEXT,
  tenses TEXT,
  examples TEXT,
  FOREIGN KEY (set_id) REFERENCES sets(id) ON DELETE CASCADE
) STRICT;

CREATE TABLE recovery_codes (
  code TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  updated_at INTEGER
) STRICT;

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin', 'user')),
  created_at INTEGER NOT NULL
) STRICT;

CREATE TABLE sessions (
  token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) STRICT;

CREATE INDEX idx_sets_user_id ON sets(user_id);
CREATE INDEX idx_cards_set_id ON cards(set_id);
