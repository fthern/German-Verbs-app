export interface Env {
  DB: D1Database;
}

// Helper: Hash password using SHA-256
async function hashPassword(password: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + salt);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// Helper: Generate UUID-like string
function generateId(): string {
  return crypto.randomUUID();
}

// Helper: Get session user
async function getSession(request: Request, env: Env): Promise<any | null> {
  const authHeader = request.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.split(' ')[1];
  
  const { results } = await env.DB.prepare(
    'SELECT users.* FROM sessions JOIN users ON sessions.user_id = users.id WHERE sessions.token = ? AND sessions.expires_at > ?'
  ).bind(token, Date.now()).all();
  
  return results[0] || null;
}

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS headers
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Encrypted-Yw-ID, X-Is-Login, X-Project-Id, X-Yw-Env',
    };

    if (method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // --- Auth Endpoints ---

      // Check setup status
      if (path === '/api/auth/setup-status' && method === 'GET') {
        const { results } = await env.DB.prepare("SELECT count(*) as count FROM users WHERE role = 'admin'").all();
        const count = results[0].count as number;
        return new Response(JSON.stringify({ setupRequired: count === 0 }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Initial Admin Setup
      if (path === '/api/auth/setup' && method === 'POST') {
        const { username, password } = await request.json() as any;
        if (!username || !password) return new Response('Username and password required', { status: 400, headers: corsHeaders });

        // Check if admin exists
        const { results } = await env.DB.prepare("SELECT count(*) as count FROM users WHERE role = 'admin'").all();
        if ((results[0].count as number) > 0) {
          return new Response('Admin already exists', { status: 403, headers: corsHeaders });
        }

        const salt = crypto.randomUUID();
        const hash = await hashPassword(password, salt);
        const userId = generateId();

        await env.DB.prepare(
          "INSERT INTO users (id, username, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, 'admin', ?)"
        ).bind(userId, username, hash, salt, Date.now()).run();

        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Login
      if (path === '/api/auth/login' && method === 'POST') {
        const { username, password } = await request.json() as any;
        if (!username || !password) return new Response('Username and password required', { status: 400, headers: corsHeaders });

        const { results } = await env.DB.prepare("SELECT * FROM users WHERE username = ?").bind(username).all();
        const user = results[0] as any;

        if (!user) {
          return new Response('Invalid credentials', { status: 401, headers: corsHeaders });
        }

        const hash = await hashPassword(password, user.salt);
        if (hash !== user.password_hash) {
          return new Response('Invalid credentials', { status: 401, headers: corsHeaders });
        }

        const token = generateId();
        const expiresAt = Date.now() + (7 * 24 * 60 * 60 * 1000); // 7 days

        await env.DB.prepare(
          "INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)"
        ).bind(token, user.id, expiresAt).run();

        return new Response(JSON.stringify({ 
          token, 
          user: { id: user.id, username: user.username, role: user.role } 
        }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Get Current User
      if (path === '/api/auth/me' && method === 'GET') {
        const user = await getSession(request, env);
        if (!user) return new Response('Unauthorized', { status: 401, headers: corsHeaders });
        
        return new Response(JSON.stringify({ 
          id: user.id, 
          username: user.username, 
          role: user.role 
        }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Change Password (Any User)
      if (path === '/api/auth/change-password' && method === 'POST') {
        const user = await getSession(request, env);
        if (!user) return new Response('Unauthorized', { status: 401, headers: corsHeaders });

        const { currentPassword, newPassword } = await request.json() as any;
        if (!currentPassword || !newPassword) return new Response('Missing fields', { status: 400, headers: corsHeaders });

        // Verify current password
        const currentHash = await hashPassword(currentPassword, user.salt);
        if (currentHash !== user.password_hash) {
          return new Response('Mevcut şifre yanlış', { status: 401, headers: corsHeaders });
        }

        // Set new password
        const newSalt = crypto.randomUUID();
        const newHash = await hashPassword(newPassword, newSalt);

        await env.DB.prepare(
          "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?"
        ).bind(newHash, newSalt, user.id).run();

        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // --- Admin Endpoints ---

      // List Users
      if (path === '/api/auth/admin/users' && method === 'GET') {
        const user = await getSession(request, env);
        if (!user || user.role !== 'admin') return new Response('Unauthorized', { status: 401, headers: corsHeaders });

        const { results } = await env.DB.prepare("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC").all();
        return new Response(JSON.stringify(results), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Create User
      if (path === '/api/auth/users' && method === 'POST') {
        const user = await getSession(request, env);
        if (!user || user.role !== 'admin') return new Response('Unauthorized', { status: 401, headers: corsHeaders });

        const { username, password, role } = await request.json() as any;
        if (!username || !password) return new Response('Missing fields', { status: 400, headers: corsHeaders });
        
        const existing = await env.DB.prepare("SELECT id FROM users WHERE username = ?").bind(username).first();
        if (existing) return new Response('Username already exists', { status: 409, headers: corsHeaders });

        const salt = crypto.randomUUID();
        const hash = await hashPassword(password, salt);
        const newUserId = generateId();
        const newRole = role === 'admin' ? 'admin' : 'user';

        await env.DB.prepare(
          "INSERT INTO users (id, username, password_hash, salt, role, created_at) VALUES (?, ?, ?, ?, ?, ?)"
        ).bind(newUserId, username, hash, salt, newRole, Date.now()).run();

        return new Response(JSON.stringify({ success: true, id: newUserId }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Reset User Password
      if (path === '/api/auth/admin/reset-password' && method === 'POST') {
        const user = await getSession(request, env);
        if (!user || user.role !== 'admin') return new Response('Unauthorized', { status: 401, headers: corsHeaders });

        const { userId, newPassword } = await request.json() as any;
        if (!userId || !newPassword) return new Response('Missing fields', { status: 400, headers: corsHeaders });

        const newSalt = crypto.randomUUID();
        const newHash = await hashPassword(newPassword, newSalt);

        await env.DB.prepare(
          "UPDATE users SET password_hash = ?, salt = ? WHERE id = ?"
        ).bind(newHash, newSalt, userId).run();

        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // Delete User
      if (path.startsWith('/api/auth/admin/users/') && method === 'DELETE') {
        const user = await getSession(request, env);
        if (!user || user.role !== 'admin') return new Response('Unauthorized', { status: 401, headers: corsHeaders });

        const targetUserId = path.split('/').pop();
        if (targetUserId === user.id) return new Response('Cannot delete yourself', { status: 400, headers: corsHeaders });

        await env.DB.prepare("DELETE FROM users WHERE id = ?").bind(targetUserId).run();
        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      // --- Protected Data Endpoints (Shared Access) ---
      
      const user = await getSession(request, env);
      if (!user) {
        return new Response('Unauthorized', { status: 401, headers: corsHeaders });
      }
      const userId = user.id;

      if (path === '/api/sets' && method === 'GET') {
        // Shared access: Return ALL sets regardless of creator
        const { results } = await env.DB.prepare(
          'SELECT * FROM sets ORDER BY created_at DESC'
        ).all();
        
        const sets = await Promise.all(results.map(async (set: any) => {
          const countResult = await env.DB.prepare(
            'SELECT count(*) as count FROM cards WHERE set_id = ?'
          ).bind(set.id).first();
          return { ...set, card_count: countResult?.count || 0 };
        }));

        return new Response(JSON.stringify(sets), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      if (path === '/api/sets' && method === 'POST') {
        const { id, title, description, category, created_at } = await request.json() as any;
        
        const existing = await env.DB.prepare('SELECT id FROM sets WHERE id = ?').bind(id).first();
        
        if (existing) {
          // Update existing set (Shared write access)
          await env.DB.prepare(
            'UPDATE sets SET title = ?, description = ?, category = ?, updated_at = ? WHERE id = ?'
          ).bind(title, description, category, Date.now(), id).run();
        } else {
          // Create new set (Record creator)
          await env.DB.prepare(
            'INSERT INTO sets (id, user_id, title, description, category, created_at) VALUES (?, ?, ?, ?, ?, ?)'
          ).bind(id, userId, title, description, category, created_at || Date.now()).run();
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      if (path === '/api/sets/sync' && method === 'POST') {
        const { sets, cards } = await request.json() as any;

        // Upsert sets (Shared)
        for (const set of sets) {
           // Check if exists to preserve original creator if possible, or just upsert
           // For simplicity in sync, we just upsert. If it's new, we use current userId.
           // If it exists, we keep existing user_id (creator).
           const existing = await env.DB.prepare('SELECT user_id FROM sets WHERE id = ?').bind(set.id).first();
           const creatorId = existing ? existing.user_id : userId;

           await env.DB.prepare(
            'INSERT OR REPLACE INTO sets (id, user_id, title, description, category, progress, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
          ).bind(set.id, creatorId, set.title, set.description, set.category, set.progress, set.created_at).run();
        }

        // Upsert cards
        for (const card of cards) {
          await env.DB.prepare(
            'INSERT OR REPLACE INTO cards (id, set_id, term, type, translation, details, secondary_meanings, tenses, examples) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
          ).bind(
            card.id, 
            card.set_id, 
            card.term, 
            card.type, 
            card.translation, 
            card.details, 
            JSON.stringify(card.secondary_meanings), 
            JSON.stringify(card.tenses), 
            JSON.stringify(card.examples)
          ).run();
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      if (path.startsWith('/api/sets/') && method === 'DELETE') {
        const setId = path.split('/').pop();
        // Shared delete access
        await env.DB.prepare('DELETE FROM sets WHERE id = ?').bind(setId).run();
        return new Response(JSON.stringify({ success: true }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      if (path.startsWith('/api/sets/') && method === 'GET') {
        const setId = path.split('/').pop();
        // Shared read access
        const set = await env.DB.prepare('SELECT * FROM sets WHERE id = ?').bind(setId).first();
        
        if (!set) return new Response('Not found', { status: 404, headers: corsHeaders });

        const { results: cards } = await env.DB.prepare('SELECT * FROM cards WHERE set_id = ?').bind(setId).all();
        
        const parsedCards = cards.map((card: any) => ({
          ...card,
          secondary_meanings: JSON.parse(card.secondary_meanings || '[]'),
          tenses: JSON.parse(card.tenses || '[]'),
          examples: JSON.parse(card.examples || '[]')
        }));

        return new Response(JSON.stringify({ ...set, cards: parsedCards }), {
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      return new Response('Not found', { status: 404, headers: corsHeaders });

    } catch (err: any) {
      return new Response(err.message, { status: 500, headers: corsHeaders });
    }
  }
};
