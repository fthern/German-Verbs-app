import React, { useState } from 'react';
import { X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { CardType } from '../types';

interface CreateSetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (title: string, description: string, category: CardType | 'mixed') => void;
}

export const CreateSetModal: React.FC<CreateSetModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const { t } = useTranslation();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<CardType | 'mixed'>('verb');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError(t('title_required'));
      return;
    }
    onSubmit(title, description, category);
    setTitle('');
    setDescription('');
    setCategory('verb');
    setError('');
    onClose();
  };

  const categories: { value: CardType | 'mixed'; label: string }[] = [
    { value: 'verb', label: 'Verbs (Fiiller)' },
    { value: 'noun', label: 'Nouns (İsimler)' },
    { value: 'adjective', label: 'Adjectives (Sıfatlar)' },
    { value: 'adverb', label: 'Adverbs (Zarflar)' },
    { value: 'preposition', label: 'Prepositions (Edatlar)' },
    { value: 'conjunction', label: 'Conjunctions (Bağlaçlar)' },
    { value: 'pronoun', label: 'Pronouns (Zamirler)' },
    { value: 'phrase', label: 'Phrases/Greetings (Kalıplar/Selamlaşma)' },
    { value: 'mixed', label: 'Mixed (Karışık)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-sm">
      <div className="bg-white dark:bg-stone-800 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200 border border-stone-100 dark:border-stone-700">
        <div className="flex justify-between items-center p-6 border-b border-stone-100 dark:border-stone-700">
          <h2 className="text-xl font-bold font-serif text-stone-900 dark:text-white tracking-tight">{t('create_set_title')}</h2>
          <button 
            onClick={onClose}
            className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              {t('set_title')}
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all text-stone-900 dark:text-white placeholder:text-stone-400"
              placeholder="e.g. A1 Verbs"
            />
            {error && <p className="mt-1 text-sm text-red-500">{error}</p>}
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              Category (Kategori)
            </label>
            <select
              id="category"
              value={category}
              onChange={(e) => setCategory(e.target.value as any)}
              className="w-full px-4 py-3 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all text-stone-900 dark:text-white"
            >
              {categories.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="description" className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-1.5">
              {t('set_description')}
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-4 py-3 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all resize-none text-stone-900 dark:text-white placeholder:text-stone-400"
              placeholder="Optional description..."
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-medium text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-700 rounded-xl hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 text-sm font-medium text-white bg-brand-600 rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/20 hover:shadow-brand-500/30 hover:-translate-y-0.5"
            >
              {t('create')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
