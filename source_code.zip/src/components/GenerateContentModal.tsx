import React, { useState } from 'react';
import { X, Sparkles, Loader2 } from 'lucide-react';
import { CardType } from '../types';
import { generateContent } from '../services/ai';
import { useStudyStore } from '../store/useStudyStore';

interface GenerateContentModalProps {
  isOpen: boolean;
  onClose: () => void;
  setId: string;
  setCategory: CardType | 'mixed';
  existingTerms: string[];
}

export const GenerateContentModal: React.FC<GenerateContentModalProps> = ({
  isOpen,
  onClose,
  setId,
  setCategory,
  existingTerms
}) => {
  const { addCardsToSet } = useStudyStore();
  const [selectedType, setSelectedType] = useState<CardType>(
    setCategory === 'mixed' ? 'noun' : setCategory
  );
  const [count, setCount] = useState(3);
  const [isGenerating, setIsGenerating] = useState(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const newContent = await generateContent(selectedType, count, existingTerms);
      
      const cardsToAdd = newContent.map(item => ({
        ...item,
        type: (item as any).type || selectedType,
        term: (item as any).term || (item as any).verb || '???',
        translation: (item as any).translation || '???',
      }));

      addCardsToSet(setId, cardsToAdd as any);
      alert(`${newContent.length} yeni içerik başarıyla eklendi!`);
      onClose();
    } catch (error: any) {
      console.error(error);
      alert('İçerik üretilirken bir hata oluştu: ' + error.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const availableTypes: { value: CardType; label: string }[] = [
    { value: 'verb', label: 'Fiil (Verb)' },
    { value: 'noun', label: 'İsim (Noun)' },
    { value: 'adjective', label: 'Sıfat (Adjective)' },
    { value: 'adverb', label: 'Zarf (Adverb)' },
    { value: 'preposition', label: 'Edat (Preposition)' },
    { value: 'conjunction', label: 'Bağlaç (Conjunction)' },
    { value: 'pronoun', label: 'Zamir (Pronoun)' },
    { value: 'phrase', label: 'Kalıp Söz (Phrase)' },
  ];

  return (
    <div className="fixed inset-0 bg-stone-900/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-stone-800 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-stone-100 dark:border-stone-700 animate-in fade-in zoom-in duration-200">
        <div className="px-6 py-5 border-b border-stone-100 dark:border-stone-700 flex items-center justify-between bg-stone-50/50 dark:bg-stone-900/50">
          <div className="flex items-center gap-3">
            <div className="bg-brand-100 dark:bg-brand-900/30 p-2 rounded-xl">
              <Sparkles className="w-5 h-5 text-brand-600 dark:text-brand-400" />
            </div>
            <h2 className="text-lg font-bold font-serif text-stone-900 dark:text-white tracking-tight">AI ile İçerik Üret</h2>
          </div>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-2">
              İçerik Türü
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as CardType)}
              className="w-full px-4 py-3 bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 rounded-xl focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all text-stone-900 dark:text-white"
            >
              {availableTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
            {setCategory !== 'mixed' && setCategory !== selectedType && (
              <p className="text-xs text-amber-600 dark:text-amber-400 mt-2 font-medium">
                Dikkat: Set kategorisi ({setCategory}) ile seçilen tür farklı.
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 dark:text-stone-300 mb-2">
              Üretilecek Adet: {count}
            </label>
            <input
              type="range"
              min="1"
              max="20"
              value={count}
              onChange={(e) => setCount(Number(e.target.value))}
              className="w-full h-2 bg-stone-200 dark:bg-stone-700 rounded-lg appearance-none cursor-pointer accent-brand-600"
            />
            <div className="flex justify-between text-xs text-stone-400 mt-2 font-medium">
              <span>1</span>
              <span>10</span>
              <span>20</span>
            </div>
          </div>

          <div className="bg-brand-50 dark:bg-brand-900/20 p-4 rounded-xl border border-brand-100 dark:border-brand-800/30">
            <p className="text-sm text-brand-800 dark:text-brand-200 leading-relaxed">
              AI, seçilen türde ({selectedType}) daha önce bu sette olmayan yeni kelimeler üretecektir.
            </p>
          </div>
        </div>

        <div className="px-6 py-5 bg-stone-50/50 dark:bg-stone-900/50 border-t border-stone-100 dark:border-stone-700 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-5 py-2.5 text-stone-600 dark:text-stone-300 font-medium hover:bg-stone-200 dark:hover:bg-stone-700 rounded-xl transition-colors"
          >
            İptal
          </button>
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="flex items-center gap-2 px-6 py-2.5 bg-brand-600 text-white font-medium rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/20 hover:shadow-brand-500/30 hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none disabled:shadow-none"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Üretiliyor...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Üret
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
