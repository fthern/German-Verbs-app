import React from 'react';
import { StudySet } from '../types';
import { BookOpen, Edit2, Trash2, PlayCircle, List } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/useAuthStore';

interface StudySetCardProps {
  set: StudySet;
  onStudy: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

export const StudySetCard: React.FC<StudySetCardProps> = ({ set, onStudy, onEdit, onDelete }) => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const isAdmin = user?.role === 'admin';

  return (
    <div className="group bg-white dark:bg-stone-800 rounded-2xl shadow-sm border border-stone-100 dark:border-stone-700 p-6 hover:shadow-xl hover:shadow-brand-900/5 hover:-translate-y-1 transition-all duration-300">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-bold font-serif text-stone-900 dark:text-stone-100 mb-1 tracking-tight">{set.title}</h3>
          <p className="text-sm text-stone-500 dark:text-stone-400 line-clamp-2 leading-relaxed">{set.description}</p>
        </div>
        <div className="bg-brand-50 dark:bg-brand-900/20 p-2.5 rounded-xl group-hover:scale-110 transition-transform duration-300">
          <BookOpen className="w-5 h-5 text-brand-600 dark:text-brand-400" />
        </div>
      </div>

      <div className="mb-5">
        <div className="flex justify-between text-xs font-medium text-stone-500 dark:text-stone-400 mb-2">
          <span>{t('progress')}</span>
          <span>{set.progress}%</span>
        </div>
        <div className="w-full bg-stone-100 dark:bg-stone-700 rounded-full h-1.5 overflow-hidden">
          <div 
            className="bg-brand-500 dark:bg-brand-400 h-full rounded-full transition-all duration-500 ease-out" 
            style={{ width: `${set.progress}%` }}
          />
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-stone-50 dark:border-stone-700/50">
        <span className="text-xs font-medium text-stone-500 dark:text-stone-400 bg-stone-100 dark:bg-stone-700/50 px-2.5 py-1 rounded-lg">
          {t('verbs_count', { count: set.cards.length })}
        </span>
        
        <div className="flex gap-1">
          {isAdmin && (
            <button 
              onClick={() => onDelete(set.id)}
              className="p-2 text-stone-400 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
              title={t('delete')}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
          <button 
            onClick={() => navigate(`/set/${set.id}`)}
            className="p-2 text-stone-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50 dark:hover:bg-brand-900/20 rounded-xl transition-colors"
            title="Listeyi Gör"
          >
            <List className="w-4 h-4" />
          </button>
          <button 
            onClick={() => onEdit(set.id)}
            className="p-2 text-stone-400 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-brand-50 dark:hover:bg-brand-900/20 rounded-xl transition-colors"
            title={t('edit')}
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button 
            onClick={() => onStudy(set.id)}
            className="ml-2 flex items-center gap-2 px-4 py-2 bg-brand-600 dark:bg-brand-600 text-white text-sm font-medium rounded-xl hover:bg-brand-700 dark:hover:bg-brand-500 transition-all shadow-sm hover:shadow-brand-500/25 hover:shadow-lg active:scale-95"
          >
            <PlayCircle className="w-4 h-4" />
            {t('study')}
          </button>
        </div>
      </div>
    </div>
  );
};
