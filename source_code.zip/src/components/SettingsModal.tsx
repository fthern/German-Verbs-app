import React, { useRef, useState } from 'react';
import { X, Moon, Sun, Monitor, Volume2, Smartphone, RefreshCw, Download, Cloud, AlertCircle, Upload, Save, Key, Lock, LogOut, UserPlus, Shield } from 'lucide-react';
import { useThemeStore } from '../store/useThemeStore';
import { useStudyStore } from '../store/useStudyStore';
import { useAuthStore } from '../store/useAuthStore';
import { cn } from '../lib/utils';
import { AdminUsers } from '../pages/AdminUsers';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { theme, setTheme } = useThemeStore();
  const { sync, lastSyncTime, syncError, isLoading, sets, importSet } = useStudyStore();
  const { user, logout, changePassword } = useAuthStore();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [showAdminUsers, setShowAdminUsers] = useState(false);
  
  // Change Password State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [passwordMessage, setPasswordMessage] = useState('');

  const handleBackup = () => {
    const data = JSON.stringify(sets, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `almanca-yedek-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedSets = JSON.parse(event.target?.result as string);
        if (Array.isArray(importedSets)) {
          importedSets.forEach(s => importSet(s));
          alert('Yedek başarıyla yüklendi!');
          sync(); // Sync immediately after restore
        } else {
          alert('Geçersiz yedek dosyası.');
        }
      } catch (err) {
        console.error(err);
        alert('Dosya okunamadı.');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatus('loading');
    try {
      await changePassword(currentPassword, newPassword);
      setPasswordStatus('success');
      setPasswordMessage('Şifre başarıyla değiştirildi.');
      setCurrentPassword('');
      setNewPassword('');
    } catch (err: any) {
      setPasswordStatus('error');
      setPasswordMessage(err.message);
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
          <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center sticky top-0 bg-white dark:bg-gray-800 z-10">
            <h2 className="text-xl font-serif text-gray-800 dark:text-gray-100">Ayarlar</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors">
              <X size={20} className="text-gray-500 dark:text-gray-400" />
            </button>
          </div>
          
          <div className="p-6 space-y-8">
            {/* Account Section */}
            <section>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">Hesap</h3>
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-xl p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900 dark:text-gray-100 flex items-center gap-2">
                      {user?.username}
                      {user?.role === 'admin' && <Shield size={14} className="text-brand-600" />}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{user?.role === 'admin' ? 'Yönetici' : 'Kullanıcı'}</p>
                  </div>
                  <button 
                    onClick={logout}
                    className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                    title="Çıkış Yap"
                  >
                    <LogOut size={20} />
                  </button>
                </div>

                {/* Change Password Form */}
                <form onSubmit={handleChangePassword} className="space-y-3 pt-2 border-t border-gray-200 dark:border-gray-600">
                  <p className="text-xs font-medium text-gray-500">Şifre Değiştir</p>
                  <input
                    type="password"
                    placeholder="Mevcut Şifre"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm outline-none focus:ring-2 focus:ring-brand-500"
                    required
                  />
                  <input
                    type="password"
                    placeholder="Yeni Şifre"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm outline-none focus:ring-2 focus:ring-brand-500"
                    required
                  />
                  <button
                    type="submit"
                    disabled={passwordStatus === 'loading'}
                    className="w-full bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 py-2 rounded-lg text-sm font-medium hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                  >
                    {passwordStatus === 'loading' ? 'Güncelleniyor...' : 'Şifreyi Güncelle'}
                  </button>
                  {passwordStatus === 'success' && <p className="text-green-600 text-xs">{passwordMessage}</p>}
                  {passwordStatus === 'error' && <p className="text-red-500 text-xs">{passwordMessage}</p>}
                </form>

                {user?.role === 'admin' && (
                  <button
                    onClick={() => setShowAdminUsers(true)}
                    className="w-full flex items-center justify-center gap-2 bg-brand-100 dark:bg-brand-900/30 text-brand-700 dark:text-brand-300 py-2 rounded-lg hover:bg-brand-200 dark:hover:bg-brand-900/50 transition-colors mt-2"
                  >
                    <UserPlus size={18} />
                    <span>Kullanıcıları Yönet</span>
                  </button>
                )}
              </div>
            </section>

            {/* Appearance */}
            <section>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">Görünüm</h3>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => setTheme('light')}
                  className={cn(
                    "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
                    theme === 'light' 
                      ? "border-brand-500 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300" 
                      : "border-transparent bg-gray-50 dark:bg-gray-700/50 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                  )}
                >
                  <Sun size={24} />
                  <span className="text-xs font-medium">Aydınlık</span>
                </button>
                <button
                  onClick={() => setTheme('dark')}
                  className={cn(
                    "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
                    theme === 'dark' 
                      ? "border-brand-500 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300" 
                      : "border-transparent bg-gray-50 dark:bg-gray-700/50 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                  )}
                >
                  <Moon size={24} />
                  <span className="text-xs font-medium">Karanlık</span>
                </button>
                <button
                  onClick={() => setTheme('system')}
                  className={cn(
                    "flex flex-col items-center gap-2 p-3 rounded-xl border-2 transition-all",
                    theme === 'system' 
                      ? "border-brand-500 bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300" 
                      : "border-transparent bg-gray-50 dark:bg-gray-700/50 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700"
                  )}
                >
                  <Monitor size={24} />
                  <span className="text-xs font-medium">Sistem</span>
                </button>
              </div>
            </section>

            {/* Sync & Backup */}
            <section>
              <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">Veri & Yedekleme</h3>
              <div className="space-y-3">
                <button 
                  onClick={() => sync()}
                  disabled={isLoading}
                  className="w-full flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded-lg bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400", isLoading && "animate-spin")}>
                      <RefreshCw size={20} />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900 dark:text-gray-100">Senkronize Et</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        {lastSyncTime ? `Son: ${new Date(lastSyncTime).toLocaleTimeString()}` : 'Henüz yapılmadı'}
                      </p>
                    </div>
                  </div>
                  <Cloud size={20} className={cn("text-gray-400", !syncError && "text-green-500")} />
                </button>

                {syncError && (
                  <div className="p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-lg flex items-center gap-2">
                    <AlertCircle size={16} />
                    {syncError}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={handleBackup}
                    className="flex flex-col items-center gap-2 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <Download size={24} className="text-gray-600 dark:text-gray-400" />
                    <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Yedek İndir</span>
                  </button>
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="flex flex-col items-center gap-2 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <Upload size={24} className="text-gray-600 dark:text-gray-400" />
                    <span className="text-xs font-medium text-gray-700 dark:text-gray-300">Yedek Yükle</span>
                  </button>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    onChange={handleRestore}
                    accept=".json"
                    className="hidden"
                  />
                </div>
              </div>
            </section>

            {/* About */}
            <section>
              <div className="text-center p-4">
                <p className="text-sm text-gray-400 dark:text-gray-500">Youware Almanca Kartları v1.0</p>
              </div>
            </section>
          </div>
        </div>
      </div>

      {showAdminUsers && <AdminUsers onClose={() => setShowAdminUsers(false)} />}
    </>
  );
};
