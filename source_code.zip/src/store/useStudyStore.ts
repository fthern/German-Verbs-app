import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { StudySet, Flashcard, CardType } from '../types';
import { mockSets } from '../mock/sets';
import { v4 as uuidv4 } from 'uuid';
import { useAuthStore } from './useAuthStore';

interface StudyState {
  sets: StudySet[];
  isLoading: boolean;
  lastSyncTime: string | null;
  syncError: string | null;
  addSet: (title: string, description: string, category: CardType | 'mixed') => void;
  updateSet: (id: string, data: Partial<StudySet>) => void;
  deleteSet: (id: string) => void;
  addCardToSet: (setId: string, card: Omit<Flashcard, 'id'>) => void;
  addCardsToSet: (setId: string, cards: Omit<Flashcard, 'id'>[]) => void;
  importSet: (set: StudySet) => void;
  updateCardProgress: (setId: string, progress: number) => void;
  sync: () => Promise<void>;
  fetchSet: (id: string) => Promise<void>;
}

const API_URL = 'https://backend.youware.com/api';

const getHeaders = () => {
  const token = useAuthStore.getState().token;
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
};

export const useStudyStore = create<StudyState>()(
  persist(
    (set, get) => ({
      sets: mockSets,
      isLoading: false,
      lastSyncTime: null,
      syncError: null,

      fetchSet: async (id: string) => {
        set({ isLoading: true });
        
        try {
          const response = await fetch(`${API_URL}/sets/${id}`, {
            headers: getHeaders()
          });
          if (response.ok) {
            const remoteSet = await response.json();
            set((state) => {
              const exists = state.sets.some(s => s.id === remoteSet.id);
              if (exists) {
                return { sets: state.sets.map(s => s.id === remoteSet.id ? remoteSet : s) };
              } else {
                return { sets: [...state.sets, remoteSet] };
              }
            });
          }
        } catch (error) {
          console.error('Fetch set failed:', error);
        } finally {
          set({ isLoading: false });
        }
      },

      sync: async () => {
        const token = useAuthStore.getState().token;
        if (!token) return; // Don't sync if not logged in

        set({ isLoading: true, syncError: null });
        try {
          // 1. Fetch remote sets
          const res = await fetch(`${API_URL}/sets`, {
            headers: getHeaders()
          });
          
          if (!res.ok) throw new Error('Failed to fetch remote sets');
          
          const remoteSets: StudySet[] = await res.json();
          const localSets = get().sets;

          // Simple merge strategy: Remote wins if conflict, but keep local-only sets
          // Actually, for this MVP, let's just push local changes to remote and then re-fetch
          // Or better: Send local state to backend, backend merges, return new state.
          // Current backend implementation expects "sets" and "cards" to upsert.
          
          // Collect all cards
          const allCards = localSets.flatMap(s => s.cards);

          await fetch(`${API_URL}/sets/sync`, {
            method: 'POST',
            headers: getHeaders(),
            body: JSON.stringify({
              sets: localSets.map(({ cards, ...s }) => s), // Send sets without cards array
              cards: allCards
            })
          });

          set({ lastSyncTime: new Date().toISOString() });
        } catch (error: any) {
          set({ syncError: error.message });
        } finally {
          set({ isLoading: false });
        }
      },

      addSet: (title, description, category) => {
        const newSet: StudySet = {
          id: uuidv4(),
          title,
          description,
          category,
          cards: [],
          progress: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set((state) => ({ sets: [newSet, ...state.sets] }));
        get().sync();
      },

      updateSet: (id, data) => {
        set((state) => ({
          sets: state.sets.map((s) =>
            s.id === id ? { ...s, ...data, updatedAt: new Date().toISOString() } : s
          ),
        }));
        get().sync();
      },

      deleteSet: async (id) => {
        set((state) => ({
          sets: state.sets.filter((s) => s.id !== id),
        }));
        
        // Also delete from backend
        try {
          await fetch(`${API_URL}/sets/${id}`, {
            method: 'DELETE',
            headers: getHeaders()
          });
        } catch (e) {
          console.error('Delete failed', e);
        }
      },

      addCardToSet: (setId, cardData) => {
        const newCard: Flashcard = {
          id: uuidv4(),
          ...cardData,
        };
        set((state) => ({
          sets: state.sets.map((s) =>
            s.id === setId ? { ...s, cards: [newCard, ...s.cards], updatedAt: new Date().toISOString() } : s
          ),
        }));
        get().sync();
      },

      addCardsToSet: (setId, cardsData) => {
        const newCards = cardsData.map(c => ({ ...c, id: uuidv4() }));
        set((state) => ({
          sets: state.sets.map((s) =>
            s.id === setId ? { ...s, cards: [...newCards, ...s.cards], updatedAt: new Date().toISOString() } : s
          ),
        }));
        get().sync();
      },

      importSet: (newSet) => {
        set((state) => ({
          sets: [newSet, ...state.sets]
        }));
        get().sync();
      },

      updateCardProgress: (setId, progress) => {
        set((state) => ({
          sets: state.sets.map((s) =>
            s.id === setId ? { ...s, progress, updatedAt: new Date().toISOString() } : s
          ),
        }));
        get().sync();
      },
    }),
    {
      name: 'study-storage',
      partialize: (state) => ({ sets: state.sets, lastSyncTime: state.lastSyncTime }),
    }
  )
);
