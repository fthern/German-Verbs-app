import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
  id: string;
  username: string;
  role: 'admin' | 'user';
  created_at?: number;
}

interface AuthState {
  token: string | null;
  user: User | null;
  isAuthenticated: boolean;
  setupRequired: boolean | null;
  
  setToken: (token: string | null) => void;
  setUser: (user: User | null) => void;
  checkSetupStatus: () => Promise<void>;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  setupAdmin: (username: string, password: string) => Promise<void>;
  createUser: (username: string, password: string, role: 'admin' | 'user') => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  getUsers: () => Promise<User[]>;
  deleteUser: (userId: string) => Promise<void>;
  resetPassword: (userId: string, newPassword: string) => Promise<void>;
}

const API_URL = 'https://backend.youware.com/api';

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      token: null,
      user: null,
      isAuthenticated: false,
      setupRequired: null,

      setToken: (token) => set({ token, isAuthenticated: !!token }),
      setUser: (user) => set({ user }),

      checkSetupStatus: async () => {
        try {
          const res = await fetch(`${API_URL}/auth/setup-status`);
          if (res.ok) {
            const data = await res.json();
            set({ setupRequired: data.setupRequired });
          }
        } catch (error) {
          console.error('Failed to check setup status:', error);
        }
      },

      login: async (username, password) => {
        const res = await fetch(`${API_URL}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });

        if (!res.ok) {
          throw new Error('Giriş başarısız. Kullanıcı adı veya şifre yanlış.');
        }

        const data = await res.json();
        set({ token: data.token, user: data.user, isAuthenticated: true });
      },

      logout: () => {
        set({ token: null, user: null, isAuthenticated: false });
        window.location.href = '/';
      },

      setupAdmin: async (username, password) => {
        const res = await fetch(`${API_URL}/auth/setup`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });

        if (!res.ok) {
          throw new Error('Kurulum başarısız.');
        }
        
        await get().login(username, password);
        set({ setupRequired: false });
      },

      createUser: async (username, password, role) => {
        const token = get().token;
        if (!token) throw new Error('Oturum açılmamış.');

        const res = await fetch(`${API_URL}/auth/users`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ username, password, role }),
        });

        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || 'Kullanıcı oluşturulamadı.');
        }
      },

      changePassword: async (currentPassword, newPassword) => {
        const token = get().token;
        if (!token) throw new Error('Oturum açılmamış.');

        const res = await fetch(`${API_URL}/auth/change-password`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ currentPassword, newPassword }),
        });

        if (!res.ok) {
          const msg = await res.text();
          throw new Error(msg || 'Şifre değiştirilemedi.');
        }
      },

      getUsers: async () => {
        const token = get().token;
        if (!token) throw new Error('Oturum açılmamış.');

        const res = await fetch(`${API_URL}/auth/admin/users`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!res.ok) throw new Error('Kullanıcılar getirilemedi.');
        return await res.json();
      },

      deleteUser: async (userId) => {
        const token = get().token;
        if (!token) throw new Error('Oturum açılmamış.');

        const res = await fetch(`${API_URL}/auth/admin/users/${userId}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });

        if (!res.ok) throw new Error('Kullanıcı silinemedi.');
      },

      resetPassword: async (userId, newPassword) => {
        const token = get().token;
        if (!token) throw new Error('Oturum açılmamış.');

        const res = await fetch(`${API_URL}/auth/admin/reset-password`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ userId, newPassword }),
        });

        if (!res.ok) throw new Error('Şifre sıfırlanamadı.');
      }
    }),
    {
      name: 'auth-storage-v3', // Renamed to force clear old cache
      partialize: (state) => ({ token: state.token, user: state.user, isAuthenticated: state.isAuthenticated }),
    }
  )
);
