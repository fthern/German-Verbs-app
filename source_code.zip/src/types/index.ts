export type CardType = 'verb' | 'noun' | 'adjective' | 'adverb' | 'preposition' | 'conjunction' | 'pronoun' | 'phrase' | 'other';

export interface VerbConjugation {
  person: string; // ich, du, er/sie/es, etc.
  conjugation: string; // gehe, gehst, etc.
  translation: string; // gidiyorum, gidiyorsun
  example: string; // Ich gehe jeden Morgen zur Schule.
  exampleTranslation: string; // Her sabah okula gidiyorum.
}

export interface VerbTense {
  tenseName: string; // Präsens, Präteritum, etc.
  conjugations: VerbConjugation[];
}

export interface CardExample {
  sentence: string;
  translation: string;
}

export interface Flashcard {
  id: string;
  term: string; // Main word/phrase (formerly 'verb')
  translation: string;
  type: CardType;
  secondaryMeanings?: string[]; // Yan anlamlar
  tenses?: VerbTense[]; // Only for verbs
  examples?: CardExample[]; // General examples for non-verbs (or verbs summary)
  details?: string; // Extra info (e.g. Article for nouns, Plural form)
}

export interface StudySet {
  id: string;
  title: string;
  description: string;
  category: CardType | 'mixed';
  cards: Flashcard[];
  createdAt: string;
  progress: number; // 0-100
}

export type Language = 'en' | 'tr' | 'de';
