import { generateObject } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';
import { z } from 'zod';
import { CardType } from '../types';

// --- Schemas ---

const verbConjugationSchema = z.object({
  person: z.string().describe('Person (ich, du, er/sie/es, wir, ihr, sie/Sie)'),
  conjugation: z.string().describe('Conjugated verb form'),
  translation: z.string().describe('Turkish translation of the person + verb'),
  example: z.string().describe('Example sentence in German'),
  exampleTranslation: z.string().describe('Turkish translation of the example sentence'),
});

const verbTenseSchema = z.object({
  tenseName: z.string().describe('Tense name (Präsens, Präteritum, Perfekt, Plusquamperfekt, Futur I, Futur II)'),
  conjugations: z.array(verbConjugationSchema).length(6).describe('Must contain exactly 6 items for the 6 persons'),
});

const verbCardSchema = z.object({
  term: z.string().describe('Infinitive verb in German'),
  type: z.literal('verb'),
  translation: z.string().describe('Primary Turkish translation of the infinitive'),
  secondaryMeanings: z.array(z.string()).describe('List of secondary meanings/usages in Turkish (yan anlamlar)'),
  tenses: z.array(verbTenseSchema).length(6).describe('List of exactly 6 tenses: Präsens, Präteritum, Perfekt, Plusquamperfekt, Futur I, Futur II'),
});

const generalCardSchema = z.object({
  term: z.string().describe('The word or phrase in German'),
  type: z.enum(['noun', 'adjective', 'adverb', 'preposition', 'conjunction', 'pronoun', 'phrase', 'other']),
  translation: z.string().describe('Turkish translation'),
  details: z.string().optional().describe('Extra info: Article/Plural for nouns, Comparative/Superlative for adjectives, or usage notes'),
  examples: z.array(z.object({
    sentence: z.string().describe('Example sentence in German'),
    translation: z.string().describe('Turkish translation of the example')
  })).describe('2-3 example sentences showing usage'),
});

const contentListSchema = z.object({
  items: z.array(z.union([verbCardSchema, generalCardSchema])),
});

// --- Generator Function ---

export async function generateContent(type: CardType | 'mixed', count: number, excludeTerms: string[] = []) {
  const sceneName = 'verb_generator'; // Reusing the same scene config for now
  const config = globalThis.ywConfig?.ai_config?.[sceneName];

  if (!config) {
    throw new Error(`AI Config for ${sceneName} not found`);
  }

  const openai = createOpenAI({
    baseURL: 'https://api.youware.com/public/v1/ai',
    apiKey: 'sk-YOUWARE'
  });

  let prompt = '';
  
  if (type === 'verb') {
    prompt = `Generate ${count} common, safe, and educational German verbs that are NOT in this list: ${excludeTerms.join(', ')}.
    For each verb, provide:
    1. The German Infinitive in the 'term' field (e.g. 'laufen', 'haben').
    2. Primary Turkish translation in the 'translation' field.
    3. A list of Secondary Turkish meanings (yan anlamlar).
    4. Conjugations for EXACTLY these 6 tenses: 'Präsens', 'Präteritum', 'Perfekt', 'Plusquamperfekt', 'Futur I', 'Futur II'.
    5. CRITICAL: For EACH tense, you MUST provide conjugations for ALL 6 persons: 'ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie/Sie'.
    6. CRITICAL: For EACH conjugation, provide:
       - 'conjugation': The conjugated verb (e.g. 'habe').
       - 'translation': The direct Turkish translation of ONLY the person + verb (e.g. 'benim var' or 'sahibim'). Do NOT translate the example sentence here.
       - 'example': A simple example sentence.
       - 'exampleTranslation': The Turkish translation of the example sentence.
    7. Ensure Turkish translations are accurate and natural.
    8. Ensure all content is safe, educational, and suitable for all ages.
    9. Output strictly valid JSON with type='verb'.`;
  } else if (type === 'pronoun') {
    prompt = `Generate ${count} distinct and diverse German pronouns (Zamirler) that are NOT in this list: ${excludeTerms.join(', ')}.
    Include a mix of:
    - Personal Pronouns (ich, du, er, sie, es, wir, ihr, sie, Sie)
    - Possessive Pronouns (mein, dein, sein, ihr, unser, euer, Ihr)
    - Reflexive Pronouns (mich, dich, sich, uns, euch)
    - Relative Pronouns (der, die, das, welcher, welche, welches)
    - Indefinite Pronouns (man, jemand, niemand, etwas, nichts)
    
    For each pronoun:
    1. 'term': The pronoun itself (e.g. 'mein').
    2. 'translation': Turkish translation (e.g. 'benim').
    3. 'details': Grammatical type and usage notes (e.g. 'Possessive Pronoun - 1st Person Singular').
    4. 'examples': 2-3 sentences showing how it's used in context with Turkish translations.
    
    Ensure translations are accurate and examples are helpful.`;
  } else {
    prompt = `Generate ${count} common German words/phrases (Category: ${type}) that are NOT in this list: ${excludeTerms.join(', ')}.
    For each item:
    1. 'term': The German word/phrase.
    2. 'type': The grammatical type (${type}).
    3. 'translation': Turkish translation.
    4. 'details': Any relevant grammatical info (Article for nouns, Plural, etc.).
    5. 'examples': 2-3 example sentences with Turkish translations.
    
    Ensure content is educational and safe.`;
  }

  const { object } = await generateObject({
    model: openai(config.model),
    schema: contentListSchema,
    prompt,
    temperature: 0.7,
  });

  return object.items;
}
