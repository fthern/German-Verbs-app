import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStudyStore } from '../store/useStudyStore';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Volume2, ArrowRight, CheckCircle, VolumeX } from 'lucide-react';
import { VerbConjugation, CardExample } from '../types';
import { cn } from '../lib/utils';

type StudyStep =
  | { type: 'intro'; term: string; translation: string; details?: string; secondaryMeanings?: string[]; cardId: string; index: number; total: number }
  | { type: 'conjugation'; term: string; tense: string; data: VerbConjugation; cardId: string; index: number; total: number }
  | { type: 'example'; term: string; example: CardExample; cardId: string; index: number; total: number };

export const StudySession: React.FC = () => {
  const { setId, cardId } = useParams<{ setId: string; cardId?: string }>();
  const navigate = useNavigate();
  const { sets, fetchSet } = useStudyStore();
  const set = sets.find((s) => s.id === setId);

  useEffect(() => {
    if (!set && setId) {
      fetchSet(setId);
    }
  }, [set, setId, fetchSet]);

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);
  const [voicesLoaded, setVoicesLoaded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  const steps = useMemo(() => {
    if (!set) return [];
    const allSteps: StudyStep[] = [];
    
    const cardsToStudy = cardId 
      ? set.cards.filter(c => c.id === cardId)
      : set.cards;

    cardsToStudy.forEach((card) => {
      allSteps.push({
        type: 'intro',
        term: card.term,
        translation: card.translation,
        details: card.details,
        secondaryMeanings: card.secondaryMeanings,
        cardId: card.id,
        index: 0,
        total: 0
      });

      if (card.type === 'verb' && card.tenses && Array.isArray(card.tenses)) {
        card.tenses.forEach((tense) => {
          if (tense.conjugations && Array.isArray(tense.conjugations)) {
            tense.conjugations.forEach((conj) => {
              allSteps.push({
                type: 'conjugation',
                term: card.term,
                tense: tense.tenseName,
                data: conj,
                cardId: card.id,
                index: 0,
                total: 0
              });
            });
          }
        });
      }

      if (card.examples && Array.isArray(card.examples)) {
        card.examples.forEach((ex) => {
          allSteps.push({
            type: 'example',
            term: card.term,
            example: ex,
            cardId: card.id,
            index: 0,
            total: 0
          });
        });
      }
    });

    return allSteps.map((step, i) => ({ ...step, index: i + 1, total: allSteps.length }));
  }, [set, cardId]);

  const currentStep = steps[currentStepIndex];

  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          setVoicesLoaded(true);
          // Check for German voice
          const hasGerman = voices.some(v => v.lang.startsWith('de'));
          if (!hasGerman) {
            setAudioError("Cihazınızda Almanca ses paketi bulunamadı.");
          } else {
            setAudioError(null);
          }
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
      return () => {
        window.speechSynthesis.onvoiceschanged = null;
      };
    } else {
      setAudioError("Cihazınız ses okumayı desteklemiyor.");
    }
  }, []);

  const speak = useCallback((text: string, lang: string = 'de-DE') => {
    try {
      if (typeof window === 'undefined' || !window.speechSynthesis || !text) return;
      
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = lang;
      
      const voices = window.speechSynthesis.getVoices();
      // Robust voice selection
      let voice = voices.find(v => v.lang === 'de-DE');
      if (!voice) voice = voices.find(v => v.lang === 'de_DE');
      if (!voice) voice = voices.find(v => v.lang.startsWith('de'));
      
      if (voice) {
        utterance.voice = voice;
      } else if (voices.length > 0) {
         // Fallback: if no German voice, try to warn but still play (might use default)
         console.warn("No German voice found, using default");
      }

      // Mobile fix: ensure volume is 1
      utterance.volume = 1.0;
      utterance.rate = 0.9; // Slightly slower for learning
      
      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = (e) => {
        console.error("Speech error:", e);
        setIsPlaying(false);
        setAudioError("Ses çalınırken hata oluştu.");
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error('Speech synthesis error:', e);
      setAudioError("Ses motoru hatası.");
      setIsPlaying(false);
    }
  }, []);

  const playCurrentAudio = useCallback((step: StudyStep = currentStep) => {
    if (!step) return;
    let textToSpeak = '';
    if (step.type === 'intro') {
      textToSpeak = step.term || '';
    } else if (step.type === 'conjugation' && step.data) {
      textToSpeak = `${step.data.person || ''} ${step.data.conjugation || ''}. ${step.data.example || ''}`;
    } else if (step.type === 'example' && step.example) {
      textToSpeak = step.example.sentence || '';
    }

    if (textToSpeak) {
      speak(textToSpeak);
    }
  }, [currentStep, speak]);

  // Initial play on mount if autoPlay is on (might be blocked by browser, but worth a try)
  useEffect(() => {
    if (autoPlay && voicesLoaded) {
      // Small delay to ensure voices are ready
      const timer = setTimeout(() => playCurrentAudio(), 500);
      return () => clearTimeout(timer);
    }
  }, [currentStepIndex, autoPlay, voicesLoaded, playCurrentAudio]);

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setDirection(1);
      setCurrentStepIndex((prev) => prev + 1);
    } else {
      if (cardId) {
        navigate(`/set/${setId}`);
      } else {
        navigate('/');
      }
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setDirection(-1);
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  if (!set || steps.length === 0) {
    return <div className="p-8 text-center">Set or card not found.</div>;
  }

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9
    })
  };

  const handleTestAudio = () => {
    const voices = window.speechSynthesis.getVoices();
    const deVoice = voices.find(v => v.lang.startsWith('de'));
    
    if (voices.length === 0) {
      alert("Ses motoru henüz yüklenmedi veya cihazınızda ses paketi yok. Lütfen bekleyin veya sayfayı yenileyin.");
      return;
    }

    if (!deVoice) {
      alert(`Cihazınızda ${voices.length} ses bulundu ancak Almanca ses paketi yok. Ayarlardan Almanca dil paketini yükleyiniz.`);
      return;
    }

    speak("Test", "de-DE");
    alert(`Ses testi başlatıldı.\nBulunan Sesler: ${voices.length}\nSeçilen Ses: ${deVoice.name}`);
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-900 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="glass dark:glass-dark p-4 z-10 flex items-center justify-between">
        <button 
          onClick={() => cardId ? navigate(`/set/${setId}`) : navigate('/')} 
          className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full transition-colors"
        >
          <ChevronLeft className="w-6 h-6 text-stone-600 dark:text-stone-300" />
        </button>
        <div className="text-center">
          <h1 className="font-serif font-bold text-stone-900 dark:text-white tracking-tight">{set.title}</h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">{currentStep.index} / {currentStep.total}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleTestAudio}
            className="p-2 rounded-full bg-stone-100 text-stone-400 dark:bg-stone-800 hover:bg-brand-100 hover:text-brand-600 transition-colors"
            title="Test Audio"
          >
            <Volume2 className="w-5 h-5" />
          </button>
          <button
            onClick={() => setAutoPlay(!autoPlay)}
            className={cn(
              "p-2 rounded-full transition-colors",
              autoPlay 
                ? "bg-brand-100 text-brand-600 dark:bg-brand-900/30 dark:text-brand-400" 
                : "bg-stone-100 text-stone-400 dark:bg-stone-800"
            )}
          >
            {autoPlay ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Error Banner */}
      {audioError && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-4 py-2 text-xs text-center font-medium">
          {audioError}
        </div>
      )}

      {/* Card Container */}
      <div className="flex-1 flex items-center justify-center p-4 relative">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentStepIndex}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 200, damping: 25 },
              opacity: { duration: 0.3 }
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.7}
            onDragEnd={(e, { offset, velocity }) => {
              const swipe = offset.x;

              if (swipe < -100) {
                handleNext();
              } else if (swipe > 100) {
                handlePrev();
              }
            }}
            className="absolute w-full max-w-md bg-white dark:bg-stone-800 rounded-3xl shadow-2xl shadow-stone-900/10 overflow-hidden h-[65vh] flex flex-col border border-white/50 dark:border-stone-700"
          >
            {currentStep.type === 'intro' ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-brand-500 to-brand-700 text-white relative overflow-hidden">
                <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay" />
                <h2 className="text-5xl font-serif font-bold mb-4 tracking-tight relative z-10">{currentStep.term}</h2>
                <p className="text-2xl opacity-90 font-light relative z-10">{currentStep.translation}</p>
                {currentStep.details && (
                  <p className="text-lg opacity-80 mt-2 font-medium bg-white/20 px-4 py-1.5 rounded-full backdrop-blur-sm">
                    {currentStep.details}
                  </p>
                )}
                {currentStep.secondaryMeanings && currentStep.secondaryMeanings.length > 0 && (
                  <p className="text-lg opacity-75 mt-4 italic font-serif">
                    ({currentStep.secondaryMeanings.join(', ')})
                  </p>
                )}
                <button 
                  onClick={() => playCurrentAudio()}
                  className={cn(
                    "mt-12 p-4 rounded-full transition-all backdrop-blur-md border shadow-lg relative z-10 group active:scale-95",
                    isPlaying 
                      ? "bg-brand-500 border-brand-400 animate-pulse shadow-brand-500/50" 
                      : "bg-white/10 hover:bg-white/20 border-white/20"
                  )}
                >
                  <Volume2 className={cn("w-8 h-8 transition-transform", isPlaying ? "scale-110 text-white" : "group-hover:scale-110")} />
                </button>
                <p className="mt-8 text-sm opacity-60 font-medium tracking-widest uppercase relative z-10">Kaydırarak başla &rarr;</p>
              </div>
            ) : currentStep.type === 'conjugation' ? (
              <div className="flex-1 flex flex-col">
                {/* Header */}
                <div className="bg-stone-50 dark:bg-stone-900/50 p-6 border-b border-stone-100 dark:border-stone-700 flex justify-between items-center">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-widest">
                    {currentStep.tense}
                  </span>
                  <span className="text-sm font-bold text-brand-600 dark:text-brand-400 font-serif">
                    {currentStep.term}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                  <div className="mb-10">
                    <p className="text-stone-400 text-xl mb-3 font-serif italic">{currentStep.data?.person}</p>
                    <h3 className="text-5xl font-bold text-stone-800 dark:text-white mb-4 tracking-tight">{currentStep.data?.conjugation}</h3>
                    <p className="text-2xl text-brand-600 dark:text-brand-400 font-medium">{currentStep.data?.translation}</p>
                  </div>

                  <div className="w-full bg-brand-50 dark:bg-brand-900/20 rounded-2xl p-6 cursor-pointer hover:bg-brand-100 dark:hover:bg-brand-900/30 transition-colors border border-brand-100 dark:border-brand-800/30 active:scale-95"
                       onClick={() => playCurrentAudio()}>
                    <div className="flex items-start gap-4">
                      <div className="bg-white dark:bg-brand-800 p-2 rounded-full shadow-sm">
                        <Volume2 className="w-5 h-5 text-brand-500 dark:text-brand-300" />
                      </div>
                      <div className="text-left">
                        <p className="text-lg text-stone-800 dark:text-stone-200 font-medium mb-1 leading-snug">{currentStep.data?.example}</p>
                        <p className="text-stone-500 dark:text-stone-400 text-sm">{currentStep.data?.exampleTranslation}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col">
                {/* Header */}
                <div className="bg-stone-50 dark:bg-stone-900/50 p-6 border-b border-stone-100 dark:border-stone-700 flex justify-between items-center">
                  <span className="text-xs font-bold text-stone-400 uppercase tracking-widest">
                    Örnek Cümle
                  </span>
                  <span className="text-sm font-bold text-brand-600 dark:text-brand-400 font-serif">
                    {currentStep.term}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
                  <div className="w-full bg-brand-50 dark:bg-brand-900/20 rounded-3xl p-8 cursor-pointer hover:bg-brand-100 dark:hover:bg-brand-900/30 transition-colors border border-brand-100 dark:border-brand-800/30 active:scale-95"
                       onClick={() => playCurrentAudio()}>
                    <div className="flex flex-col items-center gap-6">
                      <div className="bg-white dark:bg-brand-800 p-4 rounded-full shadow-md">
                        <Volume2 className="w-8 h-8 text-brand-500 dark:text-brand-300" />
                      </div>
                      <div className="text-center">
                        <p className="text-2xl text-stone-800 dark:text-stone-200 font-medium mb-4 leading-relaxed font-serif">
                          "{currentStep.example?.sentence}"
                        </p>
                        <p className="text-lg text-stone-500 dark:text-stone-400">
                          {currentStep.example?.translation}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Controls */}
      <div className="p-8 flex justify-between items-center max-w-md mx-auto w-full">
        <button 
          onClick={handlePrev}
          disabled={currentStepIndex === 0}
          className="p-4 rounded-2xl bg-white dark:bg-stone-800 shadow-lg shadow-stone-200/50 dark:shadow-none text-stone-400 disabled:opacity-30 disabled:cursor-not-allowed hover:text-brand-600 hover:scale-105 transition-all active:scale-95"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        
        <div className="h-1.5 flex-1 mx-6 bg-stone-200 dark:bg-stone-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-brand-500 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${(currentStep.index / currentStep.total) * 100}%` }}
          />
        </div>

        <button 
          onClick={handleNext}
          className="p-4 rounded-2xl bg-brand-600 text-white shadow-lg shadow-brand-500/30 hover:bg-brand-700 hover:scale-105 transition-all active:scale-95"
        >
          {currentStepIndex === steps.length - 1 ? (
            <CheckCircle className="w-6 h-6" />
          ) : (
            <ArrowRight className="w-6 h-6" />
          )}
        </button>
      </div>
    </div>
  );
};
