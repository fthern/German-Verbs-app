import React, { useState } from 'react';
import { useStudyStore } from '../store/useStudyStore';
import { StudySetCard } from '../components/StudySetCard';
import { CreateSetModal } from '../components/CreateSetModal';
import { SettingsModal } from '../components/SettingsModal';
import { Plus, Search, BookOpen, Upload, MessageCircle, Home, Settings } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import { CardType } from '../types';
import { cn } from '../lib/utils';

export const StudySetList: React.FC = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { sets, addSet, deleteSet, importSet } = useStudyStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNav, setActiveNav] = useState<'verbs' | 'vocab' | 'phrases'>('verbs');

  const filteredSets = sets.filter(set => {
    const matchesSearch = set.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      set.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;

    if (activeNav === 'verbs') return set.category === 'verb';
    if (activeNav === 'vocab') return ['noun', 'adjective', 'adverb', 'mixed'].includes(set.category);
    if (activeNav === 'phrases') return ['phrase', 'preposition', 'conjunction'].includes(set.category);
    
    return true;
  });

  const handleCreateSet = (title: string, description: string, category: CardType | 'mixed') => {
    addSet(title, description, category);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const importedSet = JSON.parse(content);
        if (!importedSet.title || !Array.isArray(importedSet.cards)) {
          throw new Error('Invalid set format');
        }
        importSet(importedSet);
        alert('Set başarıyla içe aktarıldı!');
      } catch (error) {
        console.error(error);
        alert('Dosya okunamadı veya format hatalı.');
      }
    };
    reader.readAsText(file);
    event.target.value = '';
  };

  const handleStudy = (id: string) => {
    navigate(`/study/${id}`);
  };

  const handleEdit = (id: string) => {
    console.log('Edit set:', id);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this set?')) {
      deleteSet(id);
    }
  };

  const navItems = [
    { id: 'verbs', label: 'Fiiller', icon: Home },
    { id: 'vocab', label: 'Kelime', icon: BookOpen },
    { id: 'phrases', label: 'Kalıplar', icon: MessageCircle },
  ];

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-900 pb-32">
      {/* Header */}
      <header className="sticky top-0 z-20 glass dark:glass-dark">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-brand-600 p-2 rounded-xl shadow-lg shadow-brand-500/20">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-stone-900 dark:text-white hidden sm:block font-serif tracking-tight">{t('app_title')}</h1>
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 text-stone-500 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"
            >
              <Settings className="w-5 h-5" />
            </button>

            <label className="flex items-center gap-2 px-4 py-2 bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 text-sm font-medium rounded-xl hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors cursor-pointer">
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">İçe Aktar</span>
              <input type="file" accept=".json" onChange={handleImport} className="hidden" />
            </label>

            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white text-sm font-medium rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/20 hover:shadow-brand-500/30 active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">{t('create_set')}</span>
              <span className="sm:hidden">{t('create')}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="mb-8 relative group">
          <div className="absolute inset-0 bg-brand-500/5 rounded-2xl blur-xl group-hover:bg-brand-500/10 transition-colors duration-500" />
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400 group-focus-within:text-brand-500 transition-colors" />
            <input
              type="text"
              placeholder="Search sets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-2xl focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 outline-none transition-all shadow-sm placeholder:text-stone-400"
            />
          </div>
        </div>

        {/* Grid */}
        {filteredSets.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSets.map((set) => (
              <StudySetCard
                key={set.id}
                set={set}
                onStudy={handleStudy}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <div className="bg-stone-100 dark:bg-stone-800 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
              <BookOpen className="w-8 h-8 text-stone-400" />
            </div>
            <h3 className="text-xl font-serif font-bold text-stone-900 dark:text-white mb-2">No sets found</h3>
            <p className="text-stone-500 dark:text-stone-400 max-w-sm mx-auto mb-8">
              {activeNav === 'verbs' ? t('no_sets') : 'Bu kategoride henüz set yok. Yeni bir tane oluşturun!'}
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="px-6 py-3 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-brand-600 dark:text-brand-400 font-medium rounded-xl hover:bg-stone-50 dark:hover:bg-stone-700 transition-colors shadow-sm"
            >
              + Yeni Set Oluştur
            </button>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <div className="fixed bottom-6 left-4 right-4 z-20">
        <div className="glass dark:glass-dark rounded-2xl shadow-xl shadow-stone-900/5 border border-white/20 dark:border-white/10 max-w-md mx-auto">
          <div className="flex justify-around items-center h-16 px-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveNav(item.id as any)}
                  className={cn(
                    "relative flex-1 flex flex-col items-center justify-center h-full space-y-1 transition-all duration-300",
                    isActive ? "text-brand-600 dark:text-brand-400" : "text-stone-400 hover:text-stone-600 dark:hover:text-stone-300"
                  )}
                >
                  {isActive && (
                    <span className="absolute -top-2 w-8 h-1 bg-brand-500 rounded-b-full" />
                  )}
                  <Icon className={cn("w-6 h-6 transition-transform duration-300", isActive && "scale-110")} />
                  <span className="text-[10px] font-medium tracking-wide">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <CreateSetModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleCreateSet}
      />
      
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
};
