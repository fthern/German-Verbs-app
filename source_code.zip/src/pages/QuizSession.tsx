import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStudyStore } from '../store/useStudyStore';
import { ChevronLeft, Volume2, CheckCircle, XCircle, RefreshCw, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';

interface Question {
  german: string;
  correctTurkish: string;
  options: string[];
}

export const QuizSession: React.FC = () => {
  const { setId } = useParams<{ setId: string }>();
  const navigate = useNavigate();
  const { sets, fetchSet } = useStudyStore();
  const set = sets.find((s) => s.id === setId);

  useEffect(() => {
    if (!set && setId) {
      fetchSet(setId);
    }
  }, [set, setId, fetchSet]);

  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);
  const [isStarted, setIsStarted] = useState(false);
  const [autoAdvance, setAutoAdvance] = useState(false);
  const [voicesLoaded, setVoicesLoaded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  const playSound = (type: 'success' | 'error') => {
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      
      const audioContext = new AudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      if (type === 'success') {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(1046.50, audioContext.currentTime + 0.1);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.5);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.5);
      } else {
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(150, audioContext.currentTime);
        oscillator.frequency.linearRampToValueAtTime(100, audioContext.currentTime + 0.3);
        gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3);
        oscillator.start();
        oscillator.stop(audioContext.currentTime + 0.3);
      }
    } catch (e) {
      console.error('Audio play failed', e);
    }
  };

  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0) {
          setVoicesLoaded(true);
          // Check for German voice
          const hasGerman = voices.some(v => v.lang.startsWith('de'));
          if (!hasGerman) {
            setAudioError("Cihazınızda Almanca ses paketi bulunamadı.");
          } else {
            setAudioError(null);
          }
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
      return () => {
        window.speechSynthesis.onvoiceschanged = null;
      };
    } else {
      setAudioError("Cihazınız ses okumayı desteklemiyor.");
    }
  }, []);

  const speak = useCallback((text: string) => {
    try {
      if (typeof window === 'undefined' || !window.speechSynthesis) return;
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      
      const voices = window.speechSynthesis.getVoices();
      let voice = voices.find(v => v.lang === 'de-DE');
      if (!voice) voice = voices.find(v => v.lang === 'de_DE');
      if (!voice) voice = voices.find(v => v.lang.startsWith('de'));

      if (voice) {
        utterance.voice = voice;
      } else if (voices.length > 0) {
         console.warn("No German voice found, using default");
      }
      
      utterance.volume = 1.0;
      utterance.rate = 0.9;

      utterance.onstart = () => setIsPlaying(true);
      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = (e) => {
        console.error("Speech error:", e);
        setIsPlaying(false);
      };

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error('Speech synthesis error:', e);
      setIsPlaying(false);
    }
  }, []);

  useEffect(() => {
    if (!set) return;

    const allQuestions: Question[] = [];
    const allTranslations: string[] = [];

    set.cards.forEach(card => {
      if (card.type === 'verb' && card.tenses) {
        card.tenses.forEach(tense => {
          tense.conjugations.forEach(conj => {
            if (conj.translation) allTranslations.push(conj.translation);
          });
        });
      } else {
        if (card.translation) allTranslations.push(card.translation);
      }
    });

    set.cards.forEach(card => {
      if (card.type === 'verb' && card.tenses) {
        card.tenses.forEach(tense => {
          tense.conjugations.forEach(conj => {
            const german = `${conj.person} ${conj.conjugation}`;
            const correctTurkish = conj.translation;
            
            const distractors = new Set<string>();
            let attempts = 0;
            while (distractors.size < 3 && attempts < 50) {
              const randomTrans = allTranslations[Math.floor(Math.random() * allTranslations.length)];
              if (randomTrans !== correctTurkish) {
                distractors.add(randomTrans);
              }
              attempts++;
            }
            
            while (distractors.size < 3) {
              distractors.add(`Seçenek ${distractors.size + 1}`);
            }

            const options = [correctTurkish, ...Array.from(distractors)].sort(() => Math.random() - 0.5);

            allQuestions.push({
              german,
              correctTurkish,
              options
            });
          });
        });
      } else {
        const german = card.term;
        const correctTurkish = card.translation;
        
        const distractors = new Set<string>();
        let attempts = 0;
        while (distractors.size < 3 && attempts < 50) {
          const randomTrans = allTranslations[Math.floor(Math.random() * allTranslations.length)];
          if (randomTrans !== correctTurkish) {
            distractors.add(randomTrans);
          }
          attempts++;
        }
        
        while (distractors.size < 3) {
          distractors.add(`Seçenek ${distractors.size + 1}`);
        }

        const options = [correctTurkish, ...Array.from(distractors)].sort(() => Math.random() - 0.5);

        allQuestions.push({
          german,
          correctTurkish,
          options
        });
      }
    });

    setQuestions(allQuestions.sort(() => Math.random() - 0.5).slice(0, 20));
  }, [set]);

  const handleAnswer = (option: string) => {
    if (isAnswered) return;
    
    setSelectedOption(option);
    setIsAnswered(true);
    
    const isCorrect = option === questions[currentIndex].correctTurkish;
    if (isCorrect) {
      setScore(s => s + 1);
      playSound('success');
    } else {
      playSound('error');
    }

    if (autoAdvance) {
      setTimeout(() => {
        handleNext();
      }, 1500);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      const nextIndex = currentIndex + 1;
      setCurrentIndex(nextIndex);
      setSelectedOption(null);
      setIsAnswered(false);
      speak(questions[nextIndex].german);
    } else {
      setIsFinished(true);
    }
  };

  const handleStart = () => {
    setIsStarted(true);
    speak(questions[0].german);
  };

  const handleRestart = () => {
    setIsFinished(false);
    setIsStarted(false);
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setQuestions(prev => [...prev].sort(() => Math.random() - 0.5));
  };

  if (!set) return <div className="p-8 text-center">Set not found</div>;
  if (questions.length === 0) return <div className="p-8 text-center">Hazırlanıyor...</div>;

  if (!isStarted) {
    return (
      <div className="min-h-screen bg-stone-50 dark:bg-stone-900 flex flex-col items-center justify-center p-4">
        <div className="bg-white dark:bg-stone-800 p-8 rounded-3xl shadow-xl shadow-stone-900/5 text-center max-w-md w-full border border-stone-100 dark:border-stone-700">
          <div className="bg-brand-50 dark:bg-brand-900/20 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
            <Volume2 className="w-12 h-12 text-brand-600 dark:text-brand-400" />
          </div>
          <h2 className="text-3xl font-bold font-serif text-stone-900 dark:text-white mb-3 tracking-tight">Teste Hazır Mısın?</h2>
          <p className="text-stone-500 dark:text-stone-400 mb-10 leading-relaxed">Sesli okuma özelliği için başlat butonuna bas.</p>
          
          <button
            onClick={handleStart}
            className="w-full py-4 px-6 rounded-2xl bg-brand-600 text-white font-bold text-lg hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30 hover:shadow-brand-500/40 hover:-translate-y-0.5 active:scale-95"
          >
            Teste Başla
          </button>
        </div>
      </div>
    );
  }

  if (isFinished) {
    return (
      <div className="min-h-screen bg-stone-50 dark:bg-stone-900 flex flex-col items-center justify-center p-4">
        <div className="bg-white dark:bg-stone-800 p-8 rounded-3xl shadow-xl shadow-stone-900/5 text-center max-w-md w-full border border-stone-100 dark:border-stone-700">
          <div className="bg-yellow-50 dark:bg-yellow-900/20 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8">
            <Trophy className="w-12 h-12 text-yellow-500" />
          </div>
          <h2 className="text-3xl font-bold font-serif text-stone-900 dark:text-white mb-3 tracking-tight">Test Tamamlandı!</h2>
          <p className="text-stone-500 dark:text-stone-400 mb-10">Sonuçlarınız aşağıdadır</p>
          
          <div className="bg-brand-50 dark:bg-brand-900/20 rounded-2xl p-8 mb-10 border border-brand-100 dark:border-brand-800/30">
            <div className="text-5xl font-bold text-brand-600 dark:text-brand-400 mb-2 font-serif">
              {score} / {questions.length}
            </div>
            <div className="text-xs text-brand-400 dark:text-brand-300 font-bold tracking-widest uppercase">DOĞRU CEVAP</div>
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => navigate(`/set/${setId}`)}
              className="flex-1 py-3 px-6 rounded-xl bg-stone-100 dark:bg-stone-700 text-stone-600 dark:text-stone-300 font-semibold hover:bg-stone-200 dark:hover:bg-stone-600 transition-colors active:scale-95"
            >
              Listeye Dön
            </button>
            <button
              onClick={handleRestart}
              className="flex-1 py-3 px-6 rounded-xl bg-brand-600 text-white font-semibold hover:bg-brand-700 transition-colors flex items-center justify-center gap-2 shadow-lg shadow-brand-500/20 active:scale-95"
            >
              <RefreshCw className="w-5 h-5" />
              Tekrarla
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[currentIndex];

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-900 flex flex-col">
      {/* Header */}
      <div className="glass dark:glass-dark p-4 z-10 flex items-center justify-between border-b border-white/20 dark:border-white/5">
        <button 
          onClick={() => navigate(`/set/${setId}`)} 
          className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full transition-colors"
        >
          <ChevronLeft className="w-6 h-6 text-stone-600 dark:text-stone-300" />
        </button>
        <div className="text-center">
          <h1 className="font-bold font-serif text-stone-900 dark:text-white tracking-tight">Test Modu</h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">{currentIndex + 1} / {questions.length}</p>
        </div>
        <button
          onClick={() => setAutoAdvance(!autoAdvance)}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors border",
            autoAdvance 
              ? "bg-brand-50 dark:bg-brand-900/20 text-brand-700 dark:text-brand-300 border-brand-200 dark:border-brand-800" 
              : "bg-stone-100 dark:bg-stone-800 text-stone-500 dark:text-stone-400 border-stone-200 dark:border-stone-700"
          )}
        >
          {autoAdvance ? 'Oto: Açık' : 'Oto: Kapalı'}
        </button>
      </div>

      {/* Progress Bar */}
      <div className="h-1.5 bg-stone-200 dark:bg-stone-800">
        <div 
          className="h-full bg-brand-500 rounded-r-full transition-all duration-500 ease-out"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Error Banner */}
      {audioError && (
        <div className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-4 py-2 text-xs text-center font-medium">
          {audioError}
        </div>
      )}

      {/* Question Area */}
      <div className="flex-1 flex flex-col items-center justify-center p-6 max-w-md mx-auto w-full pb-32">
        <div className="mb-10 text-center w-full">
          <button 
            onClick={() => speak(currentQuestion.german)}
            className={cn(
              "mb-8 p-5 rounded-full transition-all shadow-lg shadow-stone-200/50 dark:shadow-none inline-flex border border-stone-100 dark:border-stone-700 active:scale-95",
              isPlaying 
                ? "bg-brand-500 text-white animate-pulse scale-110" 
                : "bg-white dark:bg-stone-800 text-brand-600 dark:text-brand-400 hover:scale-110"
            )}
          >
            <Volume2 className="w-10 h-10" />
          </button>
          <h2 className="text-4xl font-bold font-serif text-stone-900 dark:text-white mb-3 tracking-tight">{currentQuestion.german}</h2>
          <p className="text-stone-400 dark:text-stone-500 text-sm font-medium uppercase tracking-widest">Doğru çeviriyi seçin</p>
        </div>

        <div className="w-full space-y-4">
          {currentQuestion.options.map((option, idx) => {
            const isSelected = selectedOption === option;
            const isCorrect = option === currentQuestion.correctTurkish;
            
            let buttonClass = "bg-white dark:bg-stone-800 border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 hover:border-brand-300 dark:hover:border-brand-700 hover:bg-brand-50 dark:hover:bg-brand-900/10 shadow-sm";
            
            if (isAnswered) {
              if (isCorrect) {
                buttonClass = "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-500 text-emerald-700 dark:text-emerald-400 shadow-md shadow-emerald-500/10";
              } else if (isSelected && !isCorrect) {
                buttonClass = "bg-red-50 dark:bg-red-900/20 border-red-500 text-red-700 dark:text-red-400 shadow-md shadow-red-500/10";
              } else {
                buttonClass = "bg-stone-50 dark:bg-stone-900 border-stone-100 dark:border-stone-800 text-stone-400 dark:text-stone-600 opacity-50";
              }
            }

            return (
              <button
                key={`${currentIndex}-${idx}`}
                onClick={() => handleAnswer(option)}
                disabled={isAnswered}
                className={cn(
                  "w-full p-5 text-lg font-medium rounded-2xl border-2 transition-all duration-200 flex items-center justify-between focus:outline-none active:scale-[0.98]",
                  buttonClass
                )}
              >
                <span>{option}</span>
                {isAnswered && isCorrect && <CheckCircle className="w-6 h-6 text-emerald-500" />}
                {isAnswered && isSelected && !isCorrect && <XCircle className="w-6 h-6 text-red-500" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Bar for Next Button */}
      {isAnswered && !autoAdvance && (
        <div className="fixed bottom-0 left-0 right-0 p-6 bg-white/80 dark:bg-stone-900/80 backdrop-blur-xl border-t border-stone-200 dark:border-stone-800 shadow-lg animate-in slide-in-from-bottom-10 z-20">
          <div className="max-w-md mx-auto">
            <button
              onClick={handleNext}
              className="w-full py-4 px-6 rounded-2xl bg-brand-600 text-white font-bold text-lg hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/30 hover:shadow-brand-500/40 hover:-translate-y-1 active:scale-95"
            >
              {currentIndex < questions.length - 1 ? 'Devam Et' : 'Sonuçları Gör'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
