import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useStudyStore } from '../store/useStudyStore';
import { ChevronLeft, PlayCircle, Trash2, Download, BrainCircuit, Sparkles } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { GenerateContentModal } from '../components/GenerateContentModal';

export const SetDetails: React.FC = () => {
  const { setId } = useParams<{ setId: string }>();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const { sets, updateSet, fetchSet } = useStudyStore();
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const set = sets.find((s) => s.id === setId);

  React.useEffect(() => {
    if (!set && setId) {
      fetchSet(setId);
    }
  }, [set, setId, fetchSet]);

  if (!set) {
    return <div className="p-8 text-center">Set not found. Loading...</div>;
  }

  const handleExport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(set, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `${set.title.replace(/\s+/g, '_')}_export.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const handleDeleteCard = (cardId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Bu kartı silmek istediğinize emin misiniz?')) {
      const updatedCards = set.cards.filter(c => c.id !== cardId);
      updateSet(set.id, { cards: updatedCards });
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-900">
      {/* Header */}
      <div className="sticky top-0 z-10 glass dark:glass-dark border-b border-white/20 dark:border-white/5">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/')} className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-full transition-colors">
              <ChevronLeft className="w-6 h-6 text-stone-600 dark:text-stone-300" />
            </button>
            <div>
              <h1 className="text-lg font-bold font-serif text-stone-900 dark:text-white tracking-tight">{set.title}</h1>
              <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">{set.cards.length} kart</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsGenerateModalOpen(true)}
              className="p-2 text-brand-600 hover:bg-brand-50 dark:text-brand-400 dark:hover:bg-brand-900/20 rounded-xl transition-colors"
              title="AI ile Üret"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button
              onClick={handleExport}
              className="p-2 text-stone-500 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-800 rounded-xl transition-colors"
              title="Dışa Aktar (JSON)"
            >
              <Download className="w-5 h-5" />
            </button>
            <button
              onClick={() => navigate(`/quiz/${set.id}`)}
              className="flex items-center gap-2 px-4 py-2 bg-brand-600 text-white text-sm font-medium rounded-xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/20 hover:shadow-brand-500/30 active:scale-95"
            >
              <BrainCircuit className="w-4 h-4" />
              <span className="hidden sm:inline">Test</span>
            </button>
            <button
              onClick={() => navigate(`/study/${set.id}`)}
              className="flex items-center gap-2 px-4 py-2 bg-stone-800 dark:bg-stone-700 text-white text-sm font-medium rounded-xl hover:bg-stone-900 dark:hover:bg-stone-600 transition-all shadow-lg shadow-stone-900/20 hover:shadow-stone-900/30 active:scale-95"
            >
              <PlayCircle className="w-4 h-4" />
              <span className="hidden sm:inline">{t('study')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32">
        <div className="space-y-3">
          {set.cards.length === 0 ? (
            <div className="text-center py-16 bg-white dark:bg-stone-800 rounded-3xl border border-dashed border-stone-200 dark:border-stone-700">
              <p className="text-stone-500 dark:text-stone-400 font-medium">Bu sette henüz hiç kart yok.</p>
            </div>
          ) : (
            set.cards.map((card, index) => (
              <div 
                key={card.id} 
                onClick={() => navigate(`/study/${set.id}/${card.id}`)}
                className="group bg-white dark:bg-stone-800 p-4 rounded-2xl border border-stone-100 dark:border-stone-700/50 shadow-sm hover:shadow-md hover:border-brand-200 dark:hover:border-brand-800 transition-all cursor-pointer flex items-center justify-between"
              >
                <div className="flex items-center gap-5">
                  <span className="w-8 h-8 flex items-center justify-center bg-stone-100 dark:bg-stone-700 text-stone-500 dark:text-stone-400 rounded-full text-sm font-bold group-hover:bg-brand-50 dark:group-hover:bg-brand-900/20 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors font-mono">
                    {index + 1}
                  </span>
                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-bold font-serif text-stone-900 dark:text-stone-100">{card.term}</h3>
                      {card.type !== 'verb' && (
                        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 bg-stone-100 dark:bg-stone-700 text-stone-500 dark:text-stone-400 rounded-full">
                          {card.type}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-stone-500 dark:text-stone-400 font-medium">{card.translation}</p>
                    {card.secondaryMeanings && card.secondaryMeanings.length > 0 && (
                      <p className="text-xs text-stone-400 mt-1 italic">
                        {card.secondaryMeanings.join(', ')}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <button 
                    className="p-2 text-brand-600 bg-brand-50 dark:bg-brand-900/20 rounded-xl hover:scale-110 transition-transform"
                    title="Çalış"
                  >
                    <PlayCircle className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => handleDeleteCard(card.id, e)}
                    className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </main>

      {set && (
        <GenerateContentModal
          isOpen={isGenerateModalOpen}
          onClose={() => setIsGenerateModalOpen(false)}
          setId={set.id}
          setCategory={set.category}
          existingTerms={set.cards.map(c => c.term)}
        />
      )}
    </div>
  );
};
