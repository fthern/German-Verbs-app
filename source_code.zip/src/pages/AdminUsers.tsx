import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../store/useAuthStore';
import { motion } from 'framer-motion';
import { X, Trash2, RefreshCw, UserPlus, Shield, User } from 'lucide-react';

interface AdminUsersProps {
  onClose: () => void;
}

export const AdminUsers: React.FC<AdminUsersProps> = ({ onClose }) => {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Create User Form
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'admin' | 'user'>('user');
  
  // Reset Password Modal
  const [resetUserId, setResetUserId] = useState<string | null>(null);
  const [newPassword, setNewPassword] = useState('');

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const { createUser, getUsers, deleteUser, resetPassword, user: currentUser } = useAuthStore();

  const fetchUsers = async () => {
    try {
      const data = await getUsers();
      setUsers(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setActionLoading(true);
    try {
      await createUser(username, password, role);
      setSuccess('Kullanıcı oluşturuldu.');
      setUsername('');
      setPassword('');
      setRole('user');
      fetchUsers();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDelete = async (userId: string) => {
    if (!window.confirm('Bu kullanıcıyı silmek istediğinize emin misiniz?')) return;
    setActionLoading(true);
    try {
      await deleteUser(userId);
      fetchUsers();
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetUserId) return;
    setActionLoading(true);
    try {
      await resetPassword(resetUserId, newPassword);
      setResetUserId(null);
      setNewPassword('');
      alert('Şifre başarıyla sıfırlandı.');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
      >
        <div className="p-4 border-b border-stone-100 flex justify-between items-center bg-stone-50">
          <h2 className="text-xl font-serif text-stone-800">Kullanıcı Yönetimi</h2>
          <button onClick={onClose} className="p-2 hover:bg-stone-200 rounded-full">
            <X size={20} className="text-stone-500" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Create User Section */}
          <section className="bg-stone-50 p-4 rounded-xl border border-stone-100">
            <h3 className="text-sm font-medium text-stone-500 uppercase tracking-wider mb-4 flex items-center gap-2">
              <UserPlus size={16} /> Yeni Kullanıcı Ekle
            </h3>
            <form onSubmit={handleCreate} className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <input
                type="text"
                placeholder="Kullanıcı Adı"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="px-3 py-2 rounded-lg border border-stone-200 text-sm outline-none focus:ring-2 focus:ring-brand-500"
                required
              />
              <input
                type="password"
                placeholder="Şifre"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="px-3 py-2 rounded-lg border border-stone-200 text-sm outline-none focus:ring-2 focus:ring-brand-500"
                required
              />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as 'admin' | 'user')}
                className="px-3 py-2 rounded-lg border border-stone-200 text-sm outline-none focus:ring-2 focus:ring-brand-500"
              >
                <option value="user">Kullanıcı</option>
                <option value="admin">Yönetici</option>
              </select>
              <button
                type="submit"
                disabled={actionLoading}
                className="bg-brand-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-brand-700 transition-colors disabled:opacity-50"
              >
                Ekle
              </button>
            </form>
            {error && <p className="text-red-500 text-xs mt-2">{error}</p>}
            {success && <p className="text-green-600 text-xs mt-2">{success}</p>}
          </section>

          {/* Users List */}
          <section>
            <h3 className="text-sm font-medium text-stone-500 uppercase tracking-wider mb-4">Mevcut Kullanıcılar</h3>
            <div className="space-y-2">
              {users.map((u) => (
                <div key={u.id} className="flex items-center justify-between p-3 bg-white border border-stone-100 rounded-xl hover:shadow-sm transition-shadow">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-full ${u.role === 'admin' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'}`}>
                      {u.role === 'admin' ? <Shield size={16} /> : <User size={16} />}
                    </div>
                    <div>
                      <p className="font-medium text-stone-800">{u.username}</p>
                      <p className="text-xs text-stone-400">
                        {new Date(u.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setResetUserId(u.id)}
                      className="p-2 text-stone-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition-colors"
                      title="Şifre Sıfırla"
                    >
                      <RefreshCw size={16} />
                    </button>
                    {u.id !== currentUser?.id && (
                      <button
                        onClick={() => handleDelete(u.id)}
                        className="p-2 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Sil"
                      >
                        <Trash2 size={16} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Reset Password Modal Overlay */}
        {resetUserId && (
          <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px] flex items-center justify-center p-4">
            <div className="bg-white p-6 rounded-xl shadow-lg w-full max-w-sm">
              <h3 className="font-medium text-stone-800 mb-4">Şifre Sıfırla</h3>
              <form onSubmit={handleResetPassword} className="space-y-4">
                <input
                  type="password"
                  placeholder="Yeni Şifre"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-200 outline-none focus:ring-2 focus:ring-brand-500"
                  required
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setResetUserId(null)}
                    className="px-4 py-2 text-stone-600 hover:bg-stone-100 rounded-lg text-sm"
                  >
                    İptal
                  </button>
                  <button
                    type="submit"
                    disabled={actionLoading}
                    className="px-4 py-2 bg-brand-600 text-white rounded-lg text-sm hover:bg-brand-700"
                  >
                    Sıfırla
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
};
