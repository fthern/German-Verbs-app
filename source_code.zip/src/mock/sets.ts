import { StudySet, VerbTense } from '../types';
import { v4 as uuidv4 } from 'uuid';

const createTense = (name: string, conjugations: any[]): VerbTense => ({
  tenseName: name,
  conjugations: conjugations.map(c => ({
    person: c.p,
    conjugation: c.c,
    translation: c.t,
    example: c.e,
    exampleTranslation: c.et
  }))
});

// --- SET 1: TEMEL FİİLLER (TOP 20) ---
const topVerbsSet: StudySet = {
  id: 'top-verbs-set-v3',
  title: 'En Önemli 20 Almanca Fiil',
  description: 'Almanca\'da en sık kullanılan 20 fiilin tüm zaman çekimleri ve örnek cümleleri.',
  category: 'verb',
  createdAt: new Date().toISOString(),
  progress: 0,
  cards: [
    {
      id: uuidv4(),
      term: 'sein',
      type: 'verb',
      translation: 'olmak',
      secondaryMeanings: ['bulunmak', 'var olmak'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'bin', t: 'ben ...-im', e: 'Ich bin glücklich.', et: 'Mutluyum.' },
          { p: 'du', c: 'bist', t: 'sen ...-sin', e: 'Du bist mein Freund.', et: 'Sen benim arkadaşımsın.' },
          { p: 'er/sie/es', c: 'ist', t: 'o ...-dir', e: 'Er ist Lehrer.', et: 'O öğretmen.' },
          { p: 'wir', c: 'sind', t: 'biz ...-iz', e: 'Wir sind hier.', et: 'Buradayız.' },
          { p: 'ihr', c: 'seid', t: 'siz ...-siniz', e: 'Seid ihr bereit?', et: 'Hazır mısınız?' },
          { p: 'sie/Sie', c: 'sind', t: 'onlar ...-ler', e: 'Sie sind zu Hause.', et: 'Evdeler.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'war', t: 'ben ...-dim', e: 'Ich war gestern krank.', et: 'Dün hastaydım.' },
          { p: 'du', c: 'warst', t: 'sen ...-din', e: 'Warst du dort?', et: 'Orada mıydın?' },
          { p: 'er/sie/es', c: 'war', t: 'o ...-di', e: 'Es war schön.', et: 'Güzeldi.' },
          { p: 'wir', c: 'waren', t: 'biz ...-dik', e: 'Wir waren im Kino.', et: 'Sinemadaydık.' },
          { p: 'ihr', c: 'wart', t: 'siz ...-diniz', e: 'Wart ihr müde?', et: 'Yorgun muydunuz?' },
          { p: 'sie/Sie', c: 'waren', t: 'onlar ...-diler', e: 'Sie waren sehr nett.', et: 'Çok naziktiler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'bin gewesen', t: 'oldum', e: 'Ich bin in Berlin gewesen.', et: 'Berlin\'de bulundum.' },
          { p: 'du', c: 'bist gewesen', t: 'oldun', e: 'Bist du brav gewesen?', et: 'Uslu durdun mu?' },
          { p: 'er/sie/es', c: 'ist gewesen', t: 'oldu', e: 'Er ist Arzt gewesen.', et: 'O doktordu (eskiden).' },
          { p: 'wir', c: 'sind gewesen', t: 'olduk', e: 'Wir sind dort gewesen.', et: 'Orada bulunduk.' },
          { p: 'ihr', c: 'seid gewesen', t: 'oldunuz', e: 'Seid ihr dort gewesen?', et: 'Orada bulundunuz mu?' },
          { p: 'sie/Sie', c: 'sind gewesen', t: 'oldular', e: 'Sie sind immer ehrlich gewesen.', et: 'Hep dürüst oldular.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'war gewesen', t: 'olmuştum', e: 'Ich war schon dort gewesen.', et: 'Daha önce orada bulunmuştum.' },
          { p: 'du', c: 'warst gewesen', t: 'olmuştun', e: 'Warst du schon mal hier gewesen?', et: 'Daha önce burada bulunmuş muydun?' },
          { p: 'er/sie/es', c: 'war gewesen', t: 'olmuştu', e: 'Er war krank gewesen.', et: 'Hasta olmuştu.' },
          { p: 'wir', c: 'waren gewesen', t: 'olmuştuk', e: 'Wir waren Freunde gewesen.', et: 'Arkadaş olmuştuk.' },
          { p: 'ihr', c: 'wart gewesen', t: 'olmuştunuz', e: 'Wart ihr fertig gewesen?', et: 'Bitirmiş miydiniz?' },
          { p: 'sie/Sie', c: 'waren gewesen', t: 'olmuşlardı', e: 'Sie waren glücklich gewesen.', et: 'Mutlu olmuşlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde sein', t: 'olacağım', e: 'Ich werde pünktlich sein.', et: 'Zamanında orada olacağım.' },
          { p: 'du', c: 'wirst sein', t: 'olacaksın', e: 'Du wirst überrascht sein.', et: 'Şaşıracaksın.' },
          { p: 'er/sie/es', c: 'wird sein', t: 'olacak', e: 'Es wird alles gut sein.', et: 'Her şey iyi olacak.' },
          { p: 'wir', c: 'werden sein', t: 'olacağız', e: 'Wir werden da sein.', et: 'Orada olacağız.' },
          { p: 'ihr', c: 'werdet sein', t: 'olacaksınız', e: 'Werdet ihr zu Hause sein?', et: 'Evde olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden sein', t: 'olacaklar', e: 'Sie werden froh sein.', et: 'Memnun olacaklar.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gewesen sein', t: 'olmuş olacağım', e: 'Ich werde dort gewesen sein.', et: 'Orada bulunmuş olacağım.' },
          { p: 'du', c: 'wirst gewesen sein', t: 'olmuş olacaksın', e: 'Du wirst es gewesen sein.', et: 'Bunu yapan sen olmuş olacaksın.' },
          { p: 'er/sie/es', c: 'wird gewesen sein', t: 'olmuş olacak', e: 'Er wird krank gewesen sein.', et: 'Hasta olmuş olacak.' },
          { p: 'wir', c: 'werden gewesen sein', t: 'olmuş olacağız', e: 'Wir werden weg gewesen sein.', et: 'Gitmiş olacağız.' },
          { p: 'ihr', c: 'werdet gewesen sein', t: 'olmuş olacaksınız', e: 'Werdet ihr fertig gewesen sein?', et: 'Bitirmiş olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gewesen sein', t: 'olmuş olacaklar', e: 'Sie werden zufrieden gewesen sein.', et: 'Memnun kalmış olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'haben',
      type: 'verb',
      translation: 'sahip olmak',
      secondaryMeanings: ['var (bir şeye sahip olmak)'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'habe', t: 'sahibim', e: 'Ich habe ein Auto.', et: 'Bir arabam var.' },
          { p: 'du', c: 'hast', t: 'sahipsin', e: 'Hast du Zeit?', et: 'Zamanın var mı?' },
          { p: 'er/sie/es', c: 'hat', t: 'sahip', e: 'Er hat eine Schwester.', et: 'Bir kız kardeşi var.' },
          { p: 'wir', c: 'haben', t: 'sahibiz', e: 'Wir haben Hunger.', et: 'Açız (Açlığımız var).' },
          { p: 'ihr', c: 'habt', t: 'sahipsiniz', e: 'Habt ihr Geld?', et: 'Paranız var mı?' },
          { p: 'sie/Sie', c: 'haben', t: 'sahipler', e: 'Sie haben viele Bücher.', et: 'Çok kitapları var.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'hatte', t: 'sahiptim', e: 'Ich hatte einen Hund.', et: 'Bir köpeğim vardı.' },
          { p: 'du', c: 'hattest', t: 'sahiptin', e: 'Hattest du Spaß?', et: 'Eğlendin mi?' },
          { p: 'er/sie/es', c: 'hatte', t: 'sahipti', e: 'Sie hatte keine Zeit.', et: 'Zamanı yoktu.' },
          { p: 'wir', c: 'hatten', t: 'sahiptik', e: 'Wir hatten Glück.', et: 'Şanslıydık.' },
          { p: 'ihr', c: 'hattet', t: 'sahiptiniz', e: 'Hattet ihr Angst?', et: 'Korktunuz mu?' },
          { p: 'sie/Sie', c: 'hatten', t: 'sahiptiler', e: 'Sie hatten Recht.', et: 'Haklıydılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gehabt', t: 'sahip oldum', e: 'Ich habe viel Spaß gehabt.', et: 'Çok eğlendim.' },
          { p: 'du', c: 'hast gehabt', t: 'sahip oldun', e: 'Hast du Probleme gehabt?', et: 'Sorun yaşadın mı?' },
          { p: 'er/sie/es', c: 'hat gehabt', t: 'sahip oldu', e: 'Er hat Glück gehabt.', et: 'Şansı yaver gitti.' },
          { p: 'wir', c: 'haben gehabt', t: 'sahip olduk', e: 'Wir haben Zeit gehabt.', et: 'Zamanımız oldu.' },
          { p: 'ihr', c: 'habt gehabt', t: 'sahip oldunuz', e: 'Habt ihr Streit gehabt?', et: 'Kavga mı ettiniz?' },
          { p: 'sie/Sie', c: 'haben gehabt', t: 'sahip oldular', e: 'Sie haben Erfolg gehabt.', et: 'Başarılı oldular.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'hatte gehabt', t: 'sahip olmuştum', e: 'Ich hatte das Buch gehabt.', et: 'Kitaba sahip olmuştum.' },
          { p: 'du', c: 'hattest gehabt', t: 'sahip olmuştun', e: 'Hattest du es gehabt?', et: 'Ona sahip olmuş muydun?' },
          { p: 'er/sie/es', c: 'hatte gehabt', t: 'sahip olmuştu', e: 'Er hatte Glück gehabt.', et: 'Şansı yaver gitmişti.' },
          { p: 'wir', c: 'hatten gehabt', t: 'sahip olmuştuk', e: 'Wir hatten Zeit gehabt.', et: 'Zamanımız olmuştu.' },
          { p: 'ihr', c: 'hattet gehabt', t: 'sahip olmuştunuz', e: 'Hattet ihr Spaß gehabt?', et: 'Eğlenmiş miydiniz?' },
          { p: 'sie/Sie', c: 'hatten gehabt', t: 'sahip olmuşlardı', e: 'Sie hatten Erfolg gehabt.', et: 'Başarılı olmuşlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde haben', t: 'sahip olacağım', e: 'Ich werde Zeit haben.', et: 'Zamanım olacak.' },
          { p: 'du', c: 'wirst haben', t: 'sahip olacaksın', e: 'Du wirst Spaß haben.', et: 'Eğleneceksin.' },
          { p: 'er/sie/es', c: 'wird haben', t: 'sahip olacak', e: 'Er wird Erfolg haben.', et: 'Başarılı olacak.' },
          { p: 'wir', c: 'werden haben', t: 'sahip olacağız', e: 'Wir werden Hunger haben.', et: 'Acıkacağız.' },
          { p: 'ihr', c: 'werdet haben', t: 'sahip olacaksınız', e: 'Werdet ihr Zeit haben?', et: 'Zamanınız olacak mı?' },
          { p: 'sie/Sie', c: 'werden haben', t: 'sahip olacaklar', e: 'Sie werden keine Wahl haben.', et: 'Seçenekleri olmayacak.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gehabt haben', t: 'sahip olmuş olacağım', e: 'Ich werde es gehabt haben.', et: 'Ona sahip olmuş olacağım.' },
          { p: 'du', c: 'wirst gehabt haben', t: 'sahip olmuş olacaksın', e: 'Du wirst es gehabt haben.', et: 'Ona sahip olmuş olacaksın.' },
          { p: 'er/sie/es', c: 'wird gehabt haben', t: 'sahip olmuş olacak', e: 'Er wird es gehabt haben.', et: 'Ona sahip olmuş olacak.' },
          { p: 'wir', c: 'werden gehabt haben', t: 'sahip olmuş olacağız', e: 'Wir werden es gehabt haben.', et: 'Ona sahip olmuş olacağız.' },
          { p: 'ihr', c: 'werdet gehabt haben', t: 'sahip olmuş olacaksınız', e: 'Werdet ihr es gehabt haben?', et: 'Ona sahip olmuş olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gehabt haben', t: 'sahip olmuş olacaklar', e: 'Sie werden es gehabt haben.', et: 'Ona sahip olmuş olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'werden',
      type: 'verb',
      translation: 'olmak (dönüşmek)',
      secondaryMeanings: ['gelecek zaman eki (-ecek/-acak)'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'werde', t: 'oluyorum', e: 'Ich werde müde.', et: 'Yoruluyorum.' },
          { p: 'du', c: 'wirst', t: 'oluyorsun', e: 'Du wirst alt.', et: 'Yaşlanıyorsun.' },
          { p: 'er/sie/es', c: 'wird', t: 'oluyor', e: 'Es wird dunkel.', et: 'Hava kararıyor.' },
          { p: 'wir', c: 'werden', t: 'oluyoruz', e: 'Wir werden krank.', et: 'Hasta oluyoruz.' },
          { p: 'ihr', c: 'werdet', t: 'oluyorsunuz', e: 'Werdet ihr verrückt?', et: 'Deliriyor musunuz?' },
          { p: 'sie/Sie', c: 'werden', t: 'oluyorlar', e: 'Sie werden besser.', et: 'İyileşiyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'wurde', t: 'oldum', e: 'Ich wurde Lehrer.', et: 'Öğretmen oldum.' },
          { p: 'du', c: 'wurdest', t: 'oldun', e: 'Wurdest du gefragt?', et: 'Sana soruldu mu?' },
          { p: 'er/sie/es', c: 'wurde', t: 'oldu', e: 'Es wurde kalt.', et: 'Hava soğudu.' },
          { p: 'wir', c: 'wurden', t: 'olduk', e: 'Wir wurden Freunde.', et: 'Arkadaş olduk.' },
          { p: 'ihr', c: 'wurdet', t: 'oldunuz', e: 'Wurdet ihr eingeladen?', et: 'Davet edildiniz mi?' },
          { p: 'sie/Sie', c: 'wurden', t: 'oldular', e: 'Sie wurden wütend.', et: 'Kızdılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'bin geworden', t: 'oldum', e: 'Ich bin krank geworden.', et: 'Hasta oldum.' },
          { p: 'du', c: 'bist geworden', t: 'oldun', e: 'Was bist du geworden?', et: 'Ne oldun (meslek)?' },
          { p: 'er/sie/es', c: 'ist geworden', t: 'oldu', e: 'Es ist spät geworden.', et: 'Geç oldu.' },
          { p: 'wir', c: 'sind geworden', t: 'olduk', e: 'Wir sind müde geworden.', et: 'Yorulduk.' },
          { p: 'ihr', c: 'seid geworden', t: 'oldunuz', e: 'Seid ihr fertig geworden?', et: 'Bitirdiniz mi?' },
          { p: 'sie/Sie', c: 'sind geworden', t: 'oldular', e: 'Sie sind rot geworden.', et: 'Kızardılar.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'war geworden', t: 'olmuştum', e: 'Ich war krank geworden.', et: 'Hasta olmuştum.' },
          { p: 'du', c: 'warst geworden', t: 'olmuştun', e: 'Warst du müde geworden?', et: 'Yorulmuş muydun?' },
          { p: 'er/sie/es', c: 'war geworden', t: 'olmuştu', e: 'Es war dunkel geworden.', et: 'Hava kararmıştı.' },
          { p: 'wir', c: 'waren geworden', t: 'olmuştuk', e: 'Wir waren Freunde geworden.', et: 'Arkadaş olmuştuk.' },
          { p: 'ihr', c: 'wart geworden', t: 'olmuştunuz', e: 'Wart ihr fertig geworden?', et: 'Bitirmiş miydiniz?' },
          { p: 'sie/Sie', c: 'waren geworden', t: 'olmuşlardı', e: 'Sie waren wütend geworden.', et: 'Kızmışlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde werden', t: 'olacağım', e: 'Ich werde Arzt werden.', et: 'Doktor olacağım.' },
          { p: 'du', c: 'wirst werden', t: 'olacaksın', e: 'Du wirst gesund werden.', et: 'İyileşeceksin.' },
          { p: 'er/sie/es', c: 'wird werden', t: 'olacak', e: 'Alles wird gut werden.', et: 'Her şey iyi olacak.' },
          { p: 'wir', c: 'werden werden', t: 'olacağız', e: 'Wir werden sehen.', et: 'Göreceğiz.' },
          { p: 'ihr', c: 'werdet werden', t: 'olacaksınız', e: 'Werdet ihr dabei sein?', et: 'Orada olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden werden', t: 'olacaklar', e: 'Sie werden es schaffen.', et: 'Başaracaklar.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde geworden sein', t: 'olmuş olacağım', e: 'Ich werde gesund geworden sein.', et: 'İyileşmiş olacağım.' },
          { p: 'du', c: 'wirst geworden sein', t: 'olmuş olacaksın', e: 'Du wirst müde geworden sein.', et: 'Yorulmuş olacaksın.' },
          { p: 'er/sie/es', c: 'wird geworden sein', t: 'olmuş olacak', e: 'Es wird dunkel geworden sein.', et: 'Hava kararmış olacak.' },
          { p: 'wir', c: 'werden geworden sein', t: 'olmuş olacağız', e: 'Wir werden Freunde geworden sein.', et: 'Arkadaş olmuş olacağız.' },
          { p: 'ihr', c: 'werdet geworden sein', t: 'olmuş olacaksınız', e: 'Werdet ihr fertig geworden sein?', et: 'Bitirmiş olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden geworden sein', t: 'olmuş olacaklar', e: 'Sie werden wütend geworden sein.', et: 'Kızmış olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'können',
      type: 'verb',
      translation: 'yapabilmek (-ebilmek)',
      secondaryMeanings: ['bilmek (dil vb.)', 'olasılık'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'kann', t: 'yapabilirim', e: 'Ich kann Deutsch sprechen.', et: 'Almanca konuşabilirim.' },
          { p: 'du', c: 'kannst', t: 'yapabilirsin', e: 'Kannst du mir helfen?', et: 'Bana yardım edebilir misin?' },
          { p: 'er/sie/es', c: 'kann', t: 'yapabilir', e: 'Er kann gut schwimmen.', et: 'O iyi yüzebilir.' },
          { p: 'wir', c: 'können', t: 'yapabiliriz', e: 'Wir können heute kommen.', et: 'Bugün gelebiliriz.' },
          { p: 'ihr', c: 'könnt', t: 'yapabilirsiniz', e: 'Könnt ihr mich hören?', et: 'Beni duyabiliyor musunuz?' },
          { p: 'sie/Sie', c: 'können', t: 'yapabilirler', e: 'Sie können hier bleiben.', et: 'Burada kalabilirler.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'konnte', t: 'yapabildim', e: 'Ich konnte nicht schlafen.', et: 'Uyuyamadım.' },
          { p: 'du', c: 'konntest', t: 'yapabildin', e: 'Konntest du es finden?', et: 'Onu bulabildin mi?' },
          { p: 'er/sie/es', c: 'konnte', t: 'yapabildi', e: 'Er konnte nicht kommen.', et: 'Gelemedi.' },
          { p: 'wir', c: 'konnten', t: 'yapabildik', e: 'Wir konnten nichts tun.', et: 'Hiçbir şey yapamadık.' },
          { p: 'ihr', c: 'konntet', t: 'yapabildiniz', e: 'Konntet ihr es sehen?', et: 'Onu görebildiniz mi?' },
          { p: 'sie/Sie', c: 'konnten', t: 'yapabildiler', e: 'Sie konnten fliehen.', et: 'Kaçabildiler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gekonnt', t: 'yapabildim', e: 'Ich habe es nicht gekonnt.', et: 'Bunu yapamadım.' },
          { p: 'du', c: 'hast gekonnt', t: 'yapabildin', e: 'Hast du das gekonnt?', et: 'Bunu yapabildin mi?' },
          { p: 'er/sie/es', c: 'hat gekonnt', t: 'yapabildi', e: 'Er hat es gekonnt.', et: 'O bunu başardı.' },
          { p: 'wir', c: 'haben gekonnt', t: 'yapabildik', e: 'Wir haben es gekonnt.', et: 'Biz bunu başardık.' },
          { p: 'ihr', c: 'habt gekonnt', t: 'yapabildiniz', e: 'Habt ihr das gekonnt?', et: 'Bunu yapabildiniz mi?' },
          { p: 'sie/Sie', c: 'haben gekonnt', t: 'yapabildiler', e: 'Sie haben es gekonnt.', et: 'Onlar bunu başardı.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'hatte gekonnt', t: 'yapabilmiştim', e: 'Ich hatte es gekonnt.', et: 'Bunu yapabilmiştim.' },
          { p: 'du', c: 'hattest gekonnt', t: 'yapabilmiştin', e: 'Hattest du es gekonnt?', et: 'Bunu yapabilmiş miydin?' },
          { p: 'er/sie/es', c: 'hatte gekonnt', t: 'yapabilmişti', e: 'Er hatte es gekonnt.', et: 'Bunu yapabilmişti.' },
          { p: 'wir', c: 'hatten gekonnt', t: 'yapabilmiştik', e: 'Wir hatten es gekonnt.', et: 'Bunu yapabilmiştik.' },
          { p: 'ihr', c: 'hattet gekonnt', t: 'yapabilmiştiniz', e: 'Hattet ihr es gekonnt?', et: 'Bunu yapabilmiş miydiniz?' },
          { p: 'sie/Sie', c: 'hatten gekonnt', t: 'yapabilmişlerdi', e: 'Sie hatten es gekonnt.', et: 'Bunu yapabilmişlerdi.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde können', t: 'yapabileceğim', e: 'Ich werde es tun können.', et: 'Bunu yapabileceğim.' },
          { p: 'du', c: 'wirst können', t: 'yapabileceksin', e: 'Du wirst es sehen können.', et: 'Bunu görebileceksin.' },
          { p: 'er/sie/es', c: 'wird können', t: 'yapabilecek', e: 'Er wird kommen können.', et: 'Gelebilecek.' },
          { p: 'wir', c: 'werden können', t: 'yapabileceğiz', e: 'Wir werden helfen können.', et: 'Yardım edebileceğiz.' },
          { p: 'ihr', c: 'werdet können', t: 'yapabileceksiniz', e: 'Werdet ihr das können?', et: 'Bunu yapabilecek misiniz?' },
          { p: 'sie/Sie', c: 'werden können', t: 'yapabilecekler', e: 'Sie werden es verstehen können.', et: 'Bunu anlayabilecekler.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gekonnt haben', t: 'yapabilmiş olacağım', e: 'Ich werde es gekonnt haben.', et: 'Bunu yapabilmiş olacağım.' },
          { p: 'du', c: 'wirst gekonnt haben', t: 'yapabilmiş olacaksın', e: 'Du wirst es gekonnt haben.', et: 'Bunu yapabilmiş olacaksın.' },
          { p: 'er/sie/es', c: 'wird gekonnt haben', t: 'yapabilmiş olacak', e: 'Er wird es gekonnt haben.', et: 'Bunu yapabilmiş olacak.' },
          { p: 'wir', c: 'werden gekonnt haben', t: 'yapabilmiş olacağız', e: 'Wir werden es gekonnt haben.', et: 'Bunu yapabilmiş olacağız.' },
          { p: 'ihr', c: 'werdet gekonnt haben', t: 'yapabilmiş olacaksınız', e: 'Werdet ihr es gekonnt haben?', et: 'Bunu yapabilmiş olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gekonnt haben', t: 'yapabilmiş olacaklar', e: 'Sie werden es gekonnt haben.', et: 'Bunu yapabilmiş olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'müssen',
      type: 'verb',
      translation: 'zorunda olmak (-meli/-malı)',
      secondaryMeanings: ['gerekmek'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'muss', t: 'zorundayım', e: 'Ich muss jetzt gehen.', et: 'Şimdi gitmeliyim.' },
          { p: 'du', c: 'musst', t: 'zorundasın', e: 'Du musst lernen.', et: 'Ders çalışmalısın.' },
          { p: 'er/sie/es', c: 'muss', t: 'zorunda', e: 'Er muss arbeiten.', et: 'Çalışması gerekiyor.' },
          { p: 'wir', c: 'müssen', t: 'zorundayız', e: 'Wir müssen warten.', et: 'Beklemeliyiz.' },
          { p: 'ihr', c: 'müsst', t: 'zorundasınız', e: 'Müsst ihr schon los?', et: 'Gitmeniz mi gerekiyor?' },
          { p: 'sie/Sie', c: 'müssen', t: 'zorundalar', e: 'Sie müssen bezahlen.', et: 'Ödemek zorundalar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'musste', t: 'zorundaydım', e: 'Ich musste früh aufstehen.', et: 'Erken kalkmak zorundaydım.' },
          { p: 'du', c: 'musstest', t: 'zorundaydın', e: 'Musstest du lange warten?', et: 'Çok beklemek zorunda kaldın mı?' },
          { p: 'er/sie/es', c: 'musste', t: 'zorundaydı', e: 'Er musste lachen.', et: 'Gülmek zorunda kaldı.' },
          { p: 'wir', c: 'mussten', t: 'zorundaydık', e: 'Wir mussten zu Fuß gehen.', et: 'Yürümek zorunda kaldık.' },
          { p: 'ihr', c: 'musstet', t: 'zorundaydınız', e: 'Musstet ihr das tun?', et: 'Bunu yapmak zorunda mıydınız?' },
          { p: 'sie/Sie', c: 'mussten', t: 'zorundaydılar', e: 'Sie mussten fliehen.', et: 'Kaçmak zorunda kaldılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gemusst', t: 'zorunda kaldım', e: 'Ich habe es tun müssen.', et: 'Bunu yapmak zorunda kaldım.' },
          { p: 'du', c: 'hast gemusst', t: 'zorunda kaldın', e: 'Hast du das gemusst?', et: 'Buna mecbur muydun?' },
          { p: 'er/sie/es', c: 'hat gemusst', t: 'zorunda kaldı', e: 'Er hat arbeiten müssen.', et: 'Çalışmak zorunda kaldı.' },
          { p: 'wir', c: 'haben gemusst', t: 'zorunda kaldık', e: 'Wir haben warten müssen.', et: 'Beklemek zorunda kaldık.' },
          { p: 'ihr', c: 'habt gemusst', t: 'zorunda kaldınız', e: 'Habt ihr gehen müssen?', et: 'Gitmek zorunda mı kaldınız?' },
          { p: 'sie/Sie', c: 'haben gemusst', t: 'zorunda kaldılar', e: 'Sie haben zahlen müssen.', et: 'Ödemek zorunda kaldılar.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'hatte gemusst', t: 'zorunda kalmıştım', e: 'Ich hatte es tun müssen.', et: 'Bunu yapmak zorunda kalmıştım.' },
          { p: 'du', c: 'hattest gemusst', t: 'zorunda kalmıştın', e: 'Hattest du es gemusst?', et: 'Buna mecbur kalmış mıydın?' },
          { p: 'er/sie/es', c: 'hatte gemusst', t: 'zorunda kalmıştı', e: 'Er hatte arbeiten müssen.', et: 'Çalışmak zorunda kalmıştı.' },
          { p: 'wir', c: 'hatten gemusst', t: 'zorunda kalmıştık', e: 'Wir hatten warten müssen.', et: 'Beklemek zorunda kalmıştık.' },
          { p: 'ihr', c: 'hattet gemusst', t: 'zorunda kalmıştınız', e: 'Hattet ihr gehen müssen?', et: 'Gitmek zorunda kalmış mıydınız?' },
          { p: 'sie/Sie', c: 'hatten gemusst', t: 'zorunda kalmışlardı', e: 'Sie hatten zahlen müssen.', et: 'Ödemek zorunda kalmışlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde müssen', t: 'zorunda kalacağım', e: 'Ich werde arbeiten müssen.', et: 'Çalışmak zorunda kalacağım.' },
          { p: 'du', c: 'wirst müssen', t: 'zorunda kalacaksın', e: 'Du wirst lernen müssen.', et: 'Öğrenmek zorunda kalacaksın.' },
          { p: 'er/sie/es', c: 'wird müssen', t: 'zorunda kalacak', e: 'Er wird gehen müssen.', et: 'Gitmek zorunda kalacak.' },
          { p: 'wir', c: 'werden müssen', t: 'zorunda kalacağız', e: 'Wir werden sehen müssen.', et: 'Görmek zorunda kalacağız.' },
          { p: 'ihr', c: 'werdet müssen', t: 'zorunda kalacaksınız', e: 'Werdet ihr das tun müssen?', et: 'Bunu yapmak zorunda kalacak mısınız?' },
          { p: 'sie/Sie', c: 'werden müssen', t: 'zorunda kalacaklar', e: 'Sie werden warten müssen.', et: 'Beklemek zorunda kalacaklar.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gemusst haben', t: 'zorunda kalmış olacağım', e: 'Ich werde es gemusst haben.', et: 'Buna mecbur kalmış olacağım.' },
          { p: 'du', c: 'wirst gemusst haben', t: 'zorunda kalmış olacaksın', e: 'Du wirst es gemusst haben.', et: 'Buna mecbur kalmış olacaksın.' },
          { p: 'er/sie/es', c: 'wird gemusst haben', t: 'zorunda kalmış olacak', e: 'Er wird es gemusst haben.', et: 'Buna mecbur kalmış olacak.' },
          { p: 'wir', c: 'werden gemusst haben', t: 'zorunda kalmış olacağız', e: 'Wir werden es gemusst haben.', et: 'Buna mecbur kalmış olacağız.' },
          { p: 'ihr', c: 'werdet gemusst haben', t: 'zorunda kalmış olacaksınız', e: 'Werdet ihr es gemusst haben?', et: 'Buna mecbur kalmış olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gemusst haben', t: 'zorunda kalmış olacaklar', e: 'Sie werden es gemusst haben.', et: 'Buna mecbur kalmış olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'wollen',
      type: 'verb',
      translation: 'istemek',
      secondaryMeanings: ['niyetinde olmak'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'will', t: 'istiyorum', e: 'Ich will ein Eis.', et: 'Bir dondurma istiyorum.' },
          { p: 'du', c: 'willst', t: 'istiyorsun', e: 'Willst du mitkommen?', et: 'Gelmek istiyor musun?' },
          { p: 'er/sie/es', c: 'will', t: 'istiyor', e: 'Er will Arzt werden.', et: 'Doktor olmak istiyor.' },
          { p: 'wir', c: 'wollen', t: 'istiyoruz', e: 'Wir wollen schlafen.', et: 'Uyumak istiyoruz.' },
          { p: 'ihr', c: 'wollt', t: 'istiyorsunuz', e: 'Wollt ihr spielen?', et: 'Oynamak istiyor musunuz?' },
          { p: 'sie/Sie', c: 'wollen', t: 'istiyorlar', e: 'Sie wollen Ruhe.', et: 'Huzur istiyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'wollte', t: 'istedim', e: 'Ich wollte dich anrufen.', et: 'Seni aramak istedim.' },
          { p: 'du', c: 'wolltest', t: 'istedin', e: 'Wolltest du das?', et: 'Bunu istedin mi?' },
          { p: 'er/sie/es', c: 'wollte', t: 'istedi', e: 'Er wollte nicht essen.', et: 'Yemek yemek istemedi.' },
          { p: 'wir', c: 'wollten', t: 'istedik', e: 'Wir wollten helfen.', et: 'Yardım etmek istedik.' },
          { p: 'ihr', c: 'wolltet', t: 'istediniz', e: 'Wolltet ihr gehen?', et: 'Gitmek istediniz mi?' },
          { p: 'sie/Sie', c: 'wollten', t: 'istediler', e: 'Sie wollten bleiben.', et: 'Kalmak istediler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gewollt', t: 'istedim', e: 'Ich habe das nicht gewollt.', et: 'Bunu istemedim.' },
          { p: 'du', c: 'hast gewollt', t: 'istedin', e: 'Hast du das gewollt?', et: 'Bunu istedin mi?' },
          { p: 'er/sie/es', c: 'hat gewollt', t: 'istedi', e: 'Er hat es gewollt.', et: 'Bunu o istedi.' },
          { p: 'wir', c: 'haben gewollt', t: 'istedik', e: 'Wir haben nur das Beste gewollt.', et: 'Sadece en iyisini istedik.' },
          { p: 'ihr', c: 'habt gewollt', t: 'istediniz', e: 'Habt ihr das gewollt?', et: 'Bunu istediniz mi?' },
          { p: 'sie/Sie', c: 'haben gewollt', t: 'istediler', e: 'Sie haben es so gewollt.', et: 'Böyle olmasını istediler.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'hatte gewollt', t: 'istemiştim', e: 'Ich hatte es gewollt.', et: 'Bunu istemiştim.' },
          { p: 'du', c: 'hattest gewollt', t: 'istemiştin', e: 'Hattest du es gewollt?', et: 'Bunu istemiş miydin?' },
          { p: 'er/sie/es', c: 'hatte gewollt', t: 'istemişti', e: 'Er hatte es gewollt.', et: 'Bunu istemişti.' },
          { p: 'wir', c: 'hatten gewollt', t: 'istemiştik', e: 'Wir hatten es gewollt.', et: 'Bunu istemiştik.' },
          { p: 'ihr', c: 'hattet gewollt', t: 'istemiştiniz', e: 'Hattet ihr es gewollt?', et: 'Bunu istemiş miydiniz?' },
          { p: 'sie/Sie', c: 'hatten gewollt', t: 'istemişlerdi', e: 'Sie hatten es gewollt.', et: 'Bunu istemişlerdi.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde wollen', t: 'isteyeceğim', e: 'Ich werde es sehen wollen.', et: 'Bunu görmek isteyeceğim.' },
          { p: 'du', c: 'wirst wollen', t: 'isteyeceksin', e: 'Du wirst es haben wollen.', et: 'Buna sahip olmak isteyeceksin.' },
          { p: 'er/sie/es', c: 'wird wollen', t: 'isteyecek', e: 'Er wird kommen wollen.', et: 'Gelmek isteyecek.' },
          { p: 'wir', c: 'werden wollen', t: 'isteyeceğiz', e: 'Wir werden es wissen wollen.', et: 'Bunu bilmek isteyeceğiz.' },
          { p: 'ihr', c: 'werdet wollen', t: 'isteyeceksiniz', e: 'Werdet ihr das wollen?', et: 'Bunu isteyecek misiniz?' },
          { p: 'sie/Sie', c: 'werden wollen', t: 'isteyecekler', e: 'Sie werden es kaufen wollen.', et: 'Bunu satın almak isteyecekler.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gewollt haben', t: 'istemiş olacağım', e: 'Ich werde es gewollt haben.', et: 'Bunu istemiş olacağım.' },
          { p: 'du', c: 'wirst gewollt haben', t: 'istemiş olacaksın', e: 'Du wirst es gewollt haben.', et: 'Bunu istemiş olacaksın.' },
          { p: 'er/sie/es', c: 'wird gewollt haben', t: 'istemiş olacak', e: 'Er wird es gewollt haben.', et: 'Bunu istemiş olacak.' },
          { p: 'wir', c: 'werden gewollt haben', t: 'istemiş olacağız', e: 'Wir werden es gewollt haben.', et: 'Bunu istemiş olacağız.' },
          { p: 'ihr', c: 'werdet gewollt haben', t: 'istemiş olacaksınız', e: 'Werdet ihr es gewollt haben?', et: 'Bunu istemiş olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gewollt haben', t: 'istemiş olacaklar', e: 'Sie werden es gewollt haben.', et: 'Bunu istemiş olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'machen',
      type: 'verb',
      translation: 'yapmak',
      secondaryMeanings: ['etmek'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'mache', t: 'yapıyorum', e: 'Ich mache Hausaufgaben.', et: 'Ödev yapıyorum.' },
          { p: 'du', c: 'machst', t: 'yapıyorsun', e: 'Was machst du?', et: 'Ne yapıyorsun?' },
          { p: 'er/sie/es', c: 'macht', t: 'yapıyor', e: 'Das macht Spaß.', et: 'Bu eğlenceli.' },
          { p: 'wir', c: 'machen', t: 'yapıyoruz', e: 'Wir machen einen Ausflug.', et: 'Bir gezi yapıyoruz.' },
          { p: 'ihr', c: 'macht', t: 'yapıyorsunuz', e: 'Macht ihr mit?', et: 'Katılıyor musunuz?' },
          { p: 'sie/Sie', c: 'machen', t: 'yapıyorlar', e: 'Sie machen Lärm.', et: 'Gürültü yapıyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'machte', t: 'yaptım', e: 'Ich machte das Fenster auf.', et: 'Pencereyi açtım.' },
          { p: 'du', c: 'machtest', t: 'yaptın', e: 'Machtest du Sport?', et: 'Spor yaptın mı?' },
          { p: 'er/sie/es', c: 'machte', t: 'yaptı', e: 'Er machte einen Fehler.', et: 'Bir hata yaptı.' },
          { p: 'wir', c: 'machten', t: 'yaptık', e: 'Wir machten Urlaub.', et: 'Tatil yaptık.' },
          { p: 'ihr', c: 'machtet', t: 'yaptınız', e: 'Machtet ihr Fotos?', et: 'Fotoğraf çektiniz mi?' },
          { p: 'sie/Sie', c: 'machten', t: 'yaptılar', e: 'Sie machten Musik.', et: 'Müzik yaptılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gemacht', t: 'yaptım', e: 'Ich habe das Bett gemacht.', et: 'Yatağı topladım.' },
          { p: 'du', c: 'hast gemacht', t: 'yaptın', e: 'Was hast du gemacht?', et: 'Ne yaptın?' },
          { p: 'er/sie/es', c: 'hat gemacht', t: 'yaptı', e: 'Er hat seine Arbeit gemacht.', et: 'İşini yaptı.' },
          { p: 'wir', c: 'haben gemacht', t: 'yaptık', e: 'Wir haben alles richtig gemacht.', et: 'Her şeyi doğru yaptık.' },
          { p: 'ihr', c: 'habt gemacht', t: 'yaptınız', e: 'Habt ihr die Übung gemacht?', et: 'Alıştırmayı yaptınız mı?' },
          { p: 'sie/Sie', c: 'haben gemacht', t: 'yaptılar', e: 'Sie haben ein Foto gemacht.', et: 'Bir fotoğraf çektiler.' }
        ]),
        createTense('Plusquamperfekt', [
          { p: 'ich', c: 'hatte gemacht', t: 'yapmıştım', e: 'Ich hatte es gemacht.', et: 'Bunu yapmıştım.' },
          { p: 'du', c: 'hattest gemacht', t: 'yapmıştın', e: 'Hattest du es gemacht?', et: 'Bunu yapmış mıydın?' },
          { p: 'er/sie/es', c: 'hatte gemacht', t: 'yapmıştı', e: 'Er hatte es gemacht.', et: 'Bunu yapmıştı.' },
          { p: 'wir', c: 'hatten gemacht', t: 'yapmıştık', e: 'Wir hatten es gemacht.', et: 'Bunu yapmıştık.' },
          { p: 'ihr', c: 'hattet gemacht', t: 'yapmıştınız', e: 'Hattet ihr es gemacht?', et: 'Bunu yapmış mıydınız?' },
          { p: 'sie/Sie', c: 'hatten gemacht', t: 'yapmışlardı', e: 'Sie hatten es gemacht.', et: 'Bunu yapmışlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde machen', t: 'yapacağım', e: 'Ich werde das später machen.', et: 'Bunu sonra yapacağım.' },
          { p: 'du', c: 'wirst machen', t: 'yapacaksın', e: 'Du wirst das gut machen.', et: 'Bunu iyi yapacaksın.' },
          { p: 'er/sie/es', c: 'wird machen', t: 'yapacak', e: 'Er wird Probleme machen.', et: 'Sorun çıkaracak.' },
          { p: 'wir', c: 'werden machen', t: 'yapacağız', e: 'Wir werden eine Party machen.', et: 'Bir parti yapacağız.' },
          { p: 'ihr', c: 'werdet machen', t: 'yapacaksınız', e: 'Werdet ihr mitmachen?', et: 'Katılacak mısınız?' },
          { p: 'sie/Sie', c: 'werden machen', t: 'yapacaklar', e: 'Sie werden Augen machen.', et: 'Gözlerine inanamayacaklar.' }
        ]),
        createTense('Futur II', [
          { p: 'ich', c: 'werde gemacht haben', t: 'yapmış olacağım', e: 'Ich werde es gemacht haben.', et: 'Bunu yapmış olacağım.' },
          { p: 'du', c: 'wirst gemacht haben', t: 'yapmış olacaksın', e: 'Du wirst es gemacht haben.', et: 'Bunu yapmış olacaksın.' },
          { p: 'er/sie/es', c: 'wird gemacht haben', t: 'yapmış olacak', e: 'Er wird es gemacht haben.', et: 'Bunu yapmış olacak.' },
          { p: 'wir', c: 'werden gemacht haben', t: 'yapmış olacağız', e: 'Wir werden es gemacht haben.', et: 'Bunu yapmış olacağız.' },
          { p: 'ihr', c: 'werdet gemacht haben', t: 'yapmış olacaksınız', e: 'Werdet ihr es gemacht haben?', et: 'Bunu yapmış olacak mısınız?' },
          { p: 'sie/Sie', c: 'werden gemacht haben', t: 'yapmış olacaklar', e: 'Sie werden es gemacht haben.', et: 'Bunu yapmış olacaklar.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'gehen',
      type: 'verb',
      translation: 'gitmek',
      secondaryMeanings: ['yürümek', 'işlemek (makine)', 'olmak (mümkün)'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'gehe', t: 'gidiyorum', e: 'Ich gehe jeden Morgen zur Schule.', et: 'Her sabah okula gidiyorum.' },
          { p: 'du', c: 'gehst', t: 'gidiyorsun', e: 'Du gehst heute zur Arbeit.', et: 'Bugün işe gidiyorsun.' },
          { p: 'er/sie/es', c: 'geht', t: 'gidiyor', e: 'Er geht ins Kino.', et: 'O sinemaya gidiyor.' },
          { p: 'wir', c: 'gehen', t: 'gidiyoruz', e: 'Wir gehen zusammen essen.', et: 'Birlikte yemek yemeye gidiyoruz.' },
          { p: 'ihr', c: 'geht', t: 'gidiyorsunuz', e: 'Geht ihr schon nach Hause?', et: 'Eve mi gidiyorsunuz?' },
          { p: 'sie/Sie', c: 'gehen', t: 'gidiyorlar', e: 'Sie gehen spazieren.', et: 'Onlar yürüyüşe gidiyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'ging', t: 'gittim', e: 'Ich ging gestern in den Park.', et: 'Dün parka gittim.' },
          { p: 'du', c: 'gingst', t: 'gittin', e: 'Du gingst zu früh weg.', et: 'Çok erken gittin.' },
          { p: 'er/sie/es', c: 'ging', t: 'gitti', e: 'Es ging alles gut.', et: 'Her şey iyi gitti.' },
          { p: 'wir', c: 'gingen', t: 'gittik', e: 'Wir gingen zu Fuß.', et: 'Yürüyerek gittik.' },
          { p: 'ihr', c: 'gingt', t: 'gittiniz', e: 'Gingt ihr gestern ins Theater?', et: 'Dün tiyatroya gittiniz mi?' },
          { p: 'sie/Sie', c: 'gingen', t: 'gittiler', e: 'Sie gingen leise hinaus.', et: 'Sessizce dışarı çıktılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'bin gegangen', t: 'gittim', e: 'Ich bin schon nach Hause gegangen.', et: 'Ben çoktan eve gittim.' },
          { p: 'du', c: 'bist gegangen', t: 'gittin', e: 'Bist du schon gegangen?', et: 'Gittin mi?' },
          { p: 'er/sie/es', c: 'ist gegangen', t: 'gitti', e: 'Er ist zur Arbeit gegangen.', et: 'O işe gitti.' },
          { p: 'wir', c: 'sind gegangen', t: 'gittik', e: 'Wir sind ins Kino gegangen.', et: 'Sinemaya gittik.' },
          { p: 'ihr', c: 'seid gegangen', t: 'gittiniz', e: 'Seid ihr schon gegangen?', et: 'Gittiniz mi?' },
          { p: 'sie/Sie', c: 'sind gegangen', t: 'gittiler', e: 'Sie sind weg gegangen.', et: 'Onlar gittiler.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde gehen', t: 'gideceğim', e: 'Ich werde morgen gehen.', et: 'Yarın gideceğim.' },
          { p: 'du', c: 'wirst gehen', t: 'gideceksin', e: 'Du wirst bald gehen.', et: 'Yakında gideceksin.' },
          { p: 'er/sie/es', c: 'wird gehen', t: 'gidecek', e: 'Er wird nach Hause gehen.', et: 'O eve gidecek.' },
          { p: 'wir', c: 'werden gehen', t: 'gideceğiz', e: 'Wir werden zusammen gehen.', et: 'Birlikte gideceğiz.' },
          { p: 'ihr', c: 'werdet gehen', t: 'gideceksiniz', e: 'Werdet ihr gehen?', et: 'Gidecek misiniz?' },
          { p: 'sie/Sie', c: 'werden gehen', t: 'gidecekler', e: 'Sie werden später gehen.', et: 'Daha sonra gidecekler.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'würde gehen', t: 'giderdim', e: 'Ich würde gehen, wenn ich Zeit hätte.', et: 'Zamanım olsa giderdim.' },
          { p: 'du', c: 'würdest gehen', t: 'giderdin', e: 'Würdest du mit mir gehen?', et: 'Benimle gelir miydin?' },
          { p: 'er/sie/es', c: 'würde gehen', t: 'giderdi', e: 'Er würde gerne gehen.', et: 'O gitmek isterdi.' },
          { p: 'wir', c: 'würden gehen', t: 'giderdik', e: 'Wir würden ins Kino gehen.', et: 'Sinemaya giderdik.' },
          { p: 'ihr', c: 'würdet gehen', t: 'giderdiniz', e: 'Würdet ihr das tun?', et: 'Bunu yapar mıydınız?' },
          { p: 'sie/Sie', c: 'würden gehen', t: 'giderlerdi', e: 'Sie würden sofort gehen.', et: 'Hemen giderlerdi.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'wissen',
      type: 'verb',
      translation: 'bilmek',
      secondaryMeanings: ['haberi olmak'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'weiß', t: 'biliyorum', e: 'Ich weiß es nicht.', et: 'Bilmiyorum.' },
          { p: 'du', c: 'weißt', t: 'biliyorsun', e: 'Weißt du die Antwort?', et: 'Cevabı biliyor musun?' },
          { p: 'er/sie/es', c: 'weiß', t: 'biliyor', e: 'Er weiß alles.', et: 'O her şeyi biliyor.' },
          { p: 'wir', c: 'wissen', t: 'biliyoruz', e: 'Wir wissen Bescheid.', et: 'Haberimiz var.' },
          { p: 'ihr', c: 'wisst', t: 'biliyorsunuz', e: 'Wisst ihr, wo er ist?', et: 'Nerede olduğunu biliyor musunuz?' },
          { p: 'sie/Sie', c: 'wissen', t: 'biliyorlar', e: 'Sie wissen den Weg.', et: 'Yolu biliyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'wusste', t: 'biliyordum', e: 'Ich wusste das nicht.', et: 'Bunu bilmiyordum.' },
          { p: 'du', c: 'wusstest', t: 'biliyordun', e: 'Wusstest du das?', et: 'Bunu biliyor muydun?' },
          { p: 'er/sie/es', c: 'wusste', t: 'biliyordu', e: 'Er wusste die Antwort.', et: 'Cevabı biliyordu.' },
          { p: 'wir', c: 'wussten', t: 'biliyorduk', e: 'Wir wussten es.', et: 'Bunu biliyorduk.' },
          { p: 'ihr', c: 'wusstet', t: 'biliyordunuz', e: 'Wusstet ihr davon?', et: 'Bundan haberiniz var mıydı?' },
          { p: 'sie/Sie', c: 'wussten', t: 'biliyorlardı', e: 'Sie wussten nichts.', et: 'Hiçbir şey bilmiyorlardı.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gewusst', t: 'biliyordum', e: 'Ich habe es immer gewusst.', et: 'Bunu hep biliyordum.' },
          { p: 'du', c: 'hast gewusst', t: 'biliyordun', e: 'Hast du das gewusst?', et: 'Bunu biliyor muydun?' },
          { p: 'er/sie/es', c: 'hat gewusst', t: 'biliyordu', e: 'Er hat von nichts gewusst.', et: 'Hiçbir şeyden haberi yoktu.' },
          { p: 'wir', c: 'haben gewusst', t: 'biliyorduk', e: 'Wir haben es vorher gewusst.', et: 'Bunu önceden biliyorduk.' },
          { p: 'ihr', c: 'habt gewusst', t: 'biliyordunuz', e: 'Habt ihr das gewusst?', et: 'Bunu biliyor muydunuz?' },
          { p: 'sie/Sie', c: 'haben gewusst', t: 'biliyorlardı', e: 'Sie haben es nicht gewusst.', et: 'Bunu bilmiyorlardı.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde wissen', t: 'bileceğim', e: 'Ich werde es bald wissen.', et: 'Yakında bileceğim.' },
          { p: 'du', c: 'wirst wissen', t: 'bileceksin', e: 'Du wirst die Wahrheit wissen.', et: 'Gerçeği bileceksin.' },
          { p: 'er/sie/es', c: 'wird wissen', t: 'bilecek', e: 'Er wird es wissen.', et: 'O bunu bilecek.' },
          { p: 'wir', c: 'werden wissen', t: 'bileceğiz', e: 'Wir werden mehr wissen.', et: 'Daha fazlasını bileceğiz.' },
          { p: 'ihr', c: 'werdet wissen', t: 'bileceksiniz', e: 'Werdet ihr es wissen?', et: 'Bunu bilecek misiniz?' },
          { p: 'sie/Sie', c: 'werden wissen', t: 'bilecekler', e: 'Sie werden Bescheid wissen.', et: 'Haberleri olacak.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'wüsste', t: 'bilseydim', e: 'Ich wüsste gerne die Antwort.', et: 'Cevabı bilmek isterdim.' },
          { p: 'du', c: 'wüsstest', t: 'bilseydin', e: 'Wenn du es wüsstest...', et: 'Eğer bilseydin...' },
          { p: 'er/sie/es', c: 'wüsste', t: 'bilseydi', e: 'Er wüsste, was zu tun ist.', et: 'Ne yapacağını bilirdi.' },
          { p: 'wir', c: 'wüssten', t: 'bilseydik', e: 'Wir wüssten es.', et: 'Bunu bilirdik.' },
          { p: 'ihr', c: 'wüsstet', t: 'bilseydiniz', e: 'Wüsstet ihr einen Weg?', et: 'Bir yol biliyor muydunuz?' },
          { p: 'sie/Sie', c: 'wüssten', t: 'bilselerdi', e: 'Sie wüssten Bescheid.', et: 'Haberleri olurdu.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'sehen',
      type: 'verb',
      translation: 'görmek',
      secondaryMeanings: ['izlemek', 'bakmak'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'sehe', t: 'görüyorum', e: 'Ich sehe dich.', et: 'Seni görüyorum.' },
          { p: 'du', c: 'siehst', t: 'görüyorsun', e: 'Siehst du das?', et: 'Bunu görüyor musun?' },
          { p: 'er/sie/es', c: 'sieht', t: 'görüyor', e: 'Er sieht fern.', et: 'O televizyon izliyor.' },
          { p: 'wir', c: 'sehen', t: 'görüyoruz', e: 'Wir sehen uns morgen.', et: 'Yarın görüşürüz.' },
          { p: 'ihr', c: 'seht', t: 'görüyorsunuz', e: 'Seht ihr den Vogel?', et: 'Kuşu görüyor musunuz?' },
          { p: 'sie/Sie', c: 'sehen', t: 'görüyorlar', e: 'Sie sehen gut aus.', et: 'İyi görünüyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'sah', t: 'gördüm', e: 'Ich sah einen Film.', et: 'Bir film izledim.' },
          { p: 'du', c: 'sahst', t: 'gördün', e: 'Sahst du ihn?', et: 'Onu gördün mü?' },
          { p: 'er/sie/es', c: 'sah', t: 'gördü', e: 'Er sah müde aus.', et: 'Yorgun görünüyordu.' },
          { p: 'wir', c: 'sahen', t: 'gördük', e: 'Wir sahen das Meer.', et: 'Denizi gördük.' },
          { p: 'ihr', c: 'saht', t: 'gördünüz', e: 'Saht ihr das?', et: 'Bunu gördünüz mü?' },
          { p: 'sie/Sie', c: 'sahen', t: 'gördüler', e: 'Sie sahen weg.', et: 'Başka tarafa baktılar.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gesehen', t: 'gördüm', e: 'Ich habe dich gesehen.', et: 'Seni gördüm.' },
          { p: 'du', c: 'hast gesehen', t: 'gördün', e: 'Hast du den Film gesehen?', et: 'Filmi izledin mi?' },
          { p: 'er/sie/es', c: 'hat gesehen', t: 'gördü', e: 'Er hat alles gesehen.', et: 'Her şeyi gördü.' },
          { p: 'wir', c: 'haben gesehen', t: 'gördük', e: 'Wir haben genug gesehen.', et: 'Yeterince gördük.' },
          { p: 'ihr', c: 'habt gesehen', t: 'gördünüz', e: 'Habt ihr es gesehen?', et: 'Bunu gördünüz mü?' },
          { p: 'sie/Sie', c: 'haben gesehen', t: 'gördüler', e: 'Sie haben nichts gesehen.', et: 'Hiçbir şey görmediler.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde sehen', t: 'göreceğim', e: 'Ich werde mal sehen.', et: 'Bir bakacağım.' },
          { p: 'du', c: 'wirst sehen', t: 'göreceksin', e: 'Du wirst schon sehen.', et: 'Göreceksin (bakalım).' },
          { p: 'er/sie/es', c: 'wird sehen', t: 'görecek', e: 'Er wird es sehen.', et: 'O bunu görecek.' },
          { p: 'wir', c: 'werden sehen', t: 'göreceğiz', e: 'Wir werden sehen, was passiert.', et: 'Ne olacağını göreceğiz.' },
          { p: 'ihr', c: 'werdet sehen', t: 'göreceksiniz', e: 'Werdet ihr den Film sehen?', et: 'Filmi izleyecek misiniz?' },
          { p: 'sie/Sie', c: 'werden sehen', t: 'görecekler', e: 'Sie werden den Unterschied sehen.', et: 'Farkı görecekler.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'würde sehen', t: 'görürdüm', e: 'Ich würde gerne das Meer sehen.', et: 'Denizi görmek isterdim.' },
          { p: 'du', c: 'würdest sehen', t: 'görürdün', e: 'Würdest du nachsehen?', et: 'Kontrol eder miydin?' },
          { p: 'er/sie/es', c: 'würde sehen', t: 'görürdü', e: 'Er würde es sehen.', et: 'O bunu görürdü.' },
          { p: 'wir', c: 'würden sehen', t: 'görürdük', e: 'Wir würden uns freuen.', et: 'Sevinirdik (görsek).' },
          { p: 'ihr', c: 'würdet sehen', t: 'görürdünüz', e: 'Würdet ihr hinsehen?', et: 'Oraya bakar mıydınız?' },
          { p: 'sie/Sie', c: 'würden sehen', t: 'görürlerdi', e: 'Sie würden es sehen.', et: 'Onu görürlerdi.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'sagen',
      type: 'verb',
      translation: 'söylemek',
      secondaryMeanings: ['demek'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'sage', t: 'söylüyorum', e: 'Ich sage die Wahrheit.', et: 'Gerçeği söylüyorum.' },
          { p: 'du', c: 'sagst', t: 'söylüyorsun', e: 'Was sagst du?', et: 'Ne diyorsun?' },
          { p: 'er/sie/es', c: 'sagt', t: 'söylüyor', e: 'Er sagt nichts.', et: 'Hiçbir şey söylemiyor.' },
          { p: 'wir', c: 'sagen', t: 'söylüyoruz', e: 'Wir sagen unsere Meinung.', et: 'Fikrimizi söylüyoruz.' },
          { p: 'ihr', c: 'sagt', t: 'söylüyorsunuz', e: 'Sagt ihr Bescheid?', et: 'Haber veriyor musunuz?' },
          { p: 'sie/Sie', c: 'sagen', t: 'söylüyorlar', e: 'Sie sagen Danke.', et: 'Teşekkür ediyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'sagte', t: 'söyledim', e: 'Ich sagte Hallo.', et: 'Merhaba dedim.' },
          { p: 'du', c: 'sagtest', t: 'söyledin', e: 'Sagtest du etwas?', et: 'Bir şey mi dedin?' },
          { p: 'er/sie/es', c: 'sagte', t: 'söyledi', e: 'Er sagte Ja.', et: 'Evet dedi.' },
          { p: 'wir', c: 'sagten', t: 'söyledik', e: 'Wir sagten nichts.', et: 'Hiçbir şey demedik.' },
          { p: 'ihr', c: 'sagtet', t: 'söylediniz', e: 'Sagtet ihr Nein?', et: 'Hayır mı dediniz?' },
          { p: 'sie/Sie', c: 'sagten', t: 'söylediler', e: 'Sie sagten Tschüss.', et: 'Hoşça kal dediler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gesagt', t: 'söyledim', e: 'Ich habe es dir gesagt.', et: 'Sana söyledim.' },
          { p: 'du', c: 'hast gesagt', t: 'söyledin', e: 'Was hast du gesagt?', et: 'Ne dedin?' },
          { p: 'er/sie/es', c: 'hat gesagt', t: 'söyledi', e: 'Er hat die Wahrheit gesagt.', et: 'Gerçeği söyledi.' },
          { p: 'wir', c: 'haben gesagt', t: 'söyledik', e: 'Wir haben unsere Meinung gesagt.', et: 'Fikrimizi söyledik.' },
          { p: 'ihr', c: 'habt gesagt', t: 'söylediniz', e: 'Habt ihr das gesagt?', et: 'Bunu siz mi söylediniz?' },
          { p: 'sie/Sie', c: 'haben gesagt', t: 'söylediler', e: 'Sie haben nichts gesagt.', et: 'Hiçbir şey söylemediler.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde sagen', t: 'söyleyeceğim', e: 'Ich werde es ihm sagen.', et: 'Ona söyleyeceğim.' },
          { p: 'du', c: 'wirst sagen', t: 'söyleyeceksin', e: 'Du wirst nichts sagen.', et: 'Hiçbir şey söylemeyeceksin.' },
          { p: 'er/sie/es', c: 'wird sagen', t: 'söyleyecek', e: 'Er wird Bescheid sagen.', et: 'Haber verecek.' },
          { p: 'wir', c: 'werden sagen', t: 'söyleyeceğiz', e: 'Wir werden es allen sagen.', et: 'Herkese söyleyeceğiz.' },
          { p: 'ihr', c: 'werdet sagen', t: 'söyleyeceksiniz', e: 'Werdet ihr etwas sagen?', et: 'Bir şey söyleyecek misiniz?' },
          { p: 'sie/Sie', c: 'werden sagen', t: 'söyleyecekler', e: 'Sie werden ihre Meinung sagen.', et: 'Fikirlerini söyleyecekler.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'würde sagen', t: 'söylerdim', e: 'Ich würde sagen, dass...', et: 'Derdim ki...' },
          { p: 'du', c: 'würdest sagen', t: 'söylerdin', e: 'Würdest du das sagen?', et: 'Bunu söyler miydin?' },
          { p: 'er/sie/es', c: 'würde sagen', t: 'söylerdi', e: 'Er würde niemals lügen.', et: 'Asla yalan söylemezdi.' },
          { p: 'wir', c: 'würden sagen', t: 'söylerdik', e: 'Wir würden Ja sagen.', et: 'Evet derdik.' },
          { p: 'ihr', c: 'würdet sagen', t: 'söylerdiniz', e: 'Würdet ihr mir helfen?', et: 'Bana yardım eder miydiniz?' },
          { p: 'sie/Sie', c: 'würden sagen', t: 'söylerlerdi', e: 'Sie würden es tun.', et: 'Bunu yaparlardı.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'geben',
      type: 'verb',
      translation: 'vermek',
      secondaryMeanings: ['bulunmak (es gibt)'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'gebe', t: 'veriyorum', e: 'Ich gebe dir ein Buch.', et: 'Sana bir kitap veriyorum.' },
          { p: 'du', c: 'gibst', t: 'veriyorsun', e: 'Gibst du mir das?', et: 'Bunu bana verir misin?' },
          { p: 'er/sie/es', c: 'gibt', t: 'veriyor', e: 'Es gibt ein Problem.', et: 'Bir sorun var.' },
          { p: 'wir', c: 'geben', t: 'veriyoruz', e: 'Wir geben nicht auf.', et: 'Pes etmiyoruz.' },
          { p: 'ihr', c: 'gebt', t: 'veriyorsunuz', e: 'Gebt ihr mir Recht?', et: 'Bana hak veriyor musunuz?' },
          { p: 'sie/Sie', c: 'geben', t: 'veriyorlar', e: 'Sie geben ein Konzert.', et: 'Bir konser veriyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'gab', t: 'verdim', e: 'Ich gab ihm Geld.', et: 'Ona para verdim.' },
          { p: 'du', c: 'gabst', t: 'verdin', e: 'Gabst du mir den Schlüssel?', et: 'Anahtarı bana verdin mi?' },
          { p: 'er/sie/es', c: 'gab', t: 'verdi', e: 'Es gab viel zu essen.', et: 'Çok yemek vardı.' },
          { p: 'wir', c: 'gaben', t: 'verdik', e: 'Wir gaben unser Bestes.', et: 'Elimizden geleni yaptık.' },
          { p: 'ihr', c: 'gabt', t: 'verdiniz', e: 'Gabt ihr auf?', et: 'Pes mi ettiniz?' },
          { p: 'sie/Sie', c: 'gaben', t: 'verdiler', e: 'Sie gaben mir eine Chance.', et: 'Bana bir şans verdiler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'habe gegeben', t: 'verdim', e: 'Ich habe dir alles gegeben.', et: 'Sana her şeyi verdim.' },
          { p: 'du', c: 'hast gegeben', t: 'verdin', e: 'Hast du ihm das Buch gegeben?', et: 'Ona kitabı verdin mi?' },
          { p: 'er/sie/es', c: 'hat gegeben', t: 'verdi', e: 'Es hat Regen gegeben.', et: 'Yağmur yağdı.' },
          { p: 'wir', c: 'haben gegeben', t: 'verdik', e: 'Wir haben Antwort gegeben.', et: 'Cevap verdik.' },
          { p: 'ihr', c: 'habt gegeben', t: 'verdiniz', e: 'Habt ihr Geld gegeben?', et: 'Para verdiniz mi?' },
          { p: 'sie/Sie', c: 'haben gegeben', t: 'verdiler', e: 'Sie haben mir Recht gegeben.', et: 'Bana hak verdiler.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde geben', t: 'vereceğim', e: 'Ich werde dir Bescheid geben.', et: 'Sana haber vereceğim.' },
          { p: 'du', c: 'wirst geben', t: 'vereceksin', e: 'Du wirst mir das geben.', et: 'Bunu bana vereceksin.' },
          { p: 'er/sie/es', c: 'wird geben', t: 'verecek', e: 'Es wird Ärger geben.', et: 'Sorun çıkacak.' },
          { p: 'wir', c: 'werden geben', t: 'vereceğiz', e: 'Wir werden alles geben.', et: 'Her şeyimizi vereceğiz.' },
          { p: 'ihr', c: 'werdet geben', t: 'vereceksiniz', e: 'Werdet ihr mir das geben?', et: 'Bunu bana verecek misiniz?' },
          { p: 'sie/Sie', c: 'werden geben', t: 'vereceklar', e: 'Sie werden ein Fest geben.', et: 'Bir parti verecekler.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'würde geben', t: 'verirdim', e: 'Ich würde dir alles geben.', et: 'Sana her şeyi verirdim.' },
          { p: 'du', c: 'würdest geben', t: 'verirdin', e: 'Würdest du mir eine Chance geben?', et: 'Bana bir şans verir miydin?' },
          { p: 'er/sie/es', c: 'würde geben', t: 'verirdi', e: 'Es würde Probleme geben.', et: 'Sorunlar olurdu.' },
          { p: 'wir', c: 'würden geben', t: 'verirdik', e: 'Wir würden gerne etwas geben.', et: 'Bir şeyler vermek isterdik.' },
          { p: 'ihr', c: 'würdet geben', t: 'verirdiniz', e: 'Würdet ihr mir das geben?', et: 'Bunu bana verir miydiniz?' },
          { p: 'sie/Sie', c: 'würden geben', t: 'verirlerdi', e: 'Sie würden mir Recht geben.', et: 'Bana hak verirlerdi.' }
        ])
      ]
    },
    {
      id: uuidv4(),
      term: 'kommen',
      type: 'verb',
      translation: 'gelmek',
      secondaryMeanings: ['varmak'],
      tenses: [
        createTense('Präsens', [
          { p: 'ich', c: 'komme', t: 'geliyorum', e: 'Ich komme aus der Türkei.', et: 'Türkiye\'den geliyorum.' },
          { p: 'du', c: 'kommst', t: 'geliyorsun', e: 'Kommst du mit?', et: 'Geliyor musun?' },
          { p: 'er/sie/es', c: 'kommt', t: 'geliyor', e: 'Der Bus kommt gleich.', et: 'Otobüs birazdan geliyor.' },
          { p: 'wir', c: 'kommen', t: 'geliyoruz', e: 'Wir kommen zu spät.', et: 'Geç kalıyoruz.' },
          { p: 'ihr', c: 'kommt', t: 'geliyorsunuz', e: 'Kommt ihr morgen?', et: 'Yarın geliyor musunuz?' },
          { p: 'sie/Sie', c: 'kommen', t: 'geliyorlar', e: 'Sie kommen zu Besuch.', et: 'Ziyarete geliyorlar.' }
        ]),
        createTense('Präteritum', [
          { p: 'ich', c: 'kam', t: 'geldim', e: 'Ich kam gestern an.', et: 'Dün vardım.' },
          { p: 'du', c: 'kamst', t: 'geldin', e: 'Kamst du gut nach Hause?', et: 'Eve sağ salim vardın mı?' },
          { p: 'er/sie/es', c: 'kam', t: 'geldi', e: 'Er kam zu spät.', et: 'Geç kaldı.' },
          { p: 'wir', c: 'kamen', t: 'geldik', e: 'Wir kamen zusammen an.', et: 'Birlikte vardık.' },
          { p: 'ihr', c: 'kamt', t: 'geldiniz', e: 'Kamt ihr mit dem Auto?', et: 'Arabayla mı geldiniz?' },
          { p: 'sie/Sie', c: 'kamen', t: 'geldiler', e: 'Sie kamen nicht.', et: 'Gelmediler.' }
        ]),
        createTense('Perfekt', [
          { p: 'ich', c: 'bin gekommen', t: 'geldim', e: 'Ich bin gerade gekommen.', et: 'Az önce geldim.' },
          { p: 'du', c: 'bist gekommen', t: 'geldin', e: 'Bist du gut gekommen?', et: 'İyi geldin mi?' },
          { p: 'er/sie/es', c: 'ist gekommen', t: 'geldi', e: 'Der Winter ist gekommen.', et: 'Kış geldi.' },
          { p: 'wir', c: 'sind gekommen', t: 'geldik', e: 'Wir sind um zu helfen.', et: 'Yardım etmeye geldik.' },
          { p: 'ihr', c: 'seid gekommen', t: 'geldiniz', e: 'Seid ihr alle gekommen?', et: 'Hepiniz geldiniz mi?' },
          { p: 'sie/Sie', c: 'sind gekommen', t: 'geldiler', e: 'Sie sind pünktlich gekommen.', et: 'Tam zamanında geldiler.' }
        ]),
        createTense('Futur I', [
          { p: 'ich', c: 'werde kommen', t: 'geleceğim', e: 'Ich werde morgen kommen.', et: 'Yarın geleceğim.' },
          { p: 'du', c: 'wirst kommen', t: 'geleceksin', e: 'Du wirst sicher kommen.', et: 'Eminim geleceksin.' },
          { p: 'er/sie/es', c: 'wird kommen', t: 'gelecek', e: 'Er wird bald kommen.', et: 'Yakında gelecek.' },
          { p: 'wir', c: 'werden kommen', t: 'geleceğiz', e: 'Wir werden später kommen.', et: 'Daha sonra geleceğiz.' },
          { p: 'ihr', c: 'werdet kommen', t: 'geleceksiniz', e: 'Werdet ihr auch kommen?', et: 'Siz de gelecek misiniz?' },
          { p: 'sie/Sie', c: 'werden kommen', t: 'gelecekler', e: 'Sie werden nicht kommen.', et: 'Gelmeyecekler.' }
        ]),
        createTense('Konjunktiv II', [
          { p: 'ich', c: 'käme', t: 'gelirdim', e: 'Ich käme gerne.', et: 'Gelmek isterdim.' },
          { p: 'du', c: 'kämst', t: 'gelirdin', e: 'Kämst du, wenn du Zeit hättest?', et: 'Zamanın olsa gelir miydin?' },
          { p: 'er/sie/es', c: 'käme', t: 'gelirdi', e: 'Das käme mir gelegen.', et: 'Bu işime gelirdi.' },
          { p: 'wir', c: 'kämen', t: 'gelirdik', e: 'Wir kämen sofort.', et: 'Hemen gelirdik.' },
          { p: 'ihr', c: 'kämt', t: 'gelirdiniz', e: 'Kämt ihr bitte?', et: 'Lütfen gelir misiniz?' },
          { p: 'sie/Sie', c: 'kämen', t: 'gelirlerdi', e: 'Sie kämen sicher.', et: 'Kesin gelirlerdi.' }
        ])
      ]
    }
  ]
};

// --- SET 2: SAYILAR, RENKLER, MEVSİMLER ---
const vocabSet: StudySet = {
  id: 'vocab-basics-set-v3',
  title: 'Sayılar, Renkler ve Mevsimler',
  description: 'Almanca temel kelime bilgisi: 0-100 arası sayılar, ana renkler, mevsimler ve günler.',
  category: 'mixed',
  createdAt: new Date().toISOString(),
  progress: 0,
  cards: [
    // Sayılar
    { id: uuidv4(), term: 'null', type: 'other', translation: 'sıfır', examples: [{ sentence: 'Null Fehler.', translation: 'Sıfır hata.' }] },
    { id: uuidv4(), term: 'eins', type: 'other', translation: 'bir', examples: [{ sentence: 'Nummer eins.', translation: 'Bir numara.' }] },
    { id: uuidv4(), term: 'zwei', type: 'other', translation: 'iki', examples: [{ sentence: 'Zwei Katzen.', translation: 'İki kedi.' }] },
    { id: uuidv4(), term: 'drei', type: 'other', translation: 'üç', examples: [{ sentence: 'Aller guten Dinge sind drei.', translation: 'Hakkın üçtür.' }] },
    { id: uuidv4(), term: 'vier', type: 'other', translation: 'dört', examples: [{ sentence: 'Vier Jahreszeiten.', translation: 'Dört mevsim.' }] },
    { id: uuidv4(), term: 'fünf', type: 'other', translation: 'beş', examples: [{ sentence: 'Fünf Finger.', translation: 'Beş parmak.' }] },
    { id: uuidv4(), term: 'sechs', type: 'other', translation: 'altı', examples: [{ sentence: 'Sechs Uhr.', translation: 'Saat altı.' }] },
    { id: uuidv4(), term: 'sieben', type: 'other', translation: 'yedi', examples: [{ sentence: 'Sieben Zwerge.', translation: 'Yedi cüceler.' }] },
    { id: uuidv4(), term: 'acht', type: 'other', translation: 'sekiz', examples: [{ sentence: 'Achtung!', translation: 'Dikkat!' }] },
    { id: uuidv4(), term: 'neun', type: 'other', translation: 'dokuz', examples: [{ sentence: 'Neun Leben.', translation: 'Dokuz can.' }] },
    { id: uuidv4(), term: 'zehn', type: 'other', translation: 'on', examples: [{ sentence: 'Zehn Euro.', translation: 'On Euro.' }] },
    { id: uuidv4(), term: 'elf', type: 'other', translation: 'on bir', examples: [{ sentence: 'Elf Spieler.', translation: 'On bir oyuncu.' }] },
    { id: uuidv4(), term: 'zwölf', type: 'other', translation: 'on iki', examples: [{ sentence: 'Zwölf Monate.', translation: 'On iki ay.' }] },
    { id: uuidv4(), term: 'zwanzig', type: 'other', translation: 'yirmi', examples: [{ sentence: 'Zwanzig Minuten.', translation: 'Yirmi dakika.' }] },
    { id: uuidv4(), term: 'dreißig', type: 'other', translation: 'otuz', examples: [{ sentence: 'Dreißig Tage.', translation: 'Otuz gün.' }] },
    { id: uuidv4(), term: 'vierzig', type: 'other', translation: 'kırk', examples: [{ sentence: 'Vierzig Räuber.', translation: 'Kırk harami.' }] },
    { id: uuidv4(), term: 'fünfzig', type: 'other', translation: 'elli', examples: [{ sentence: 'Fünfzig Prozent.', translation: 'Yüzde elli.' }] },
    { id: uuidv4(), term: 'hundert', type: 'other', translation: 'yüz', examples: [{ sentence: 'Hundert Jahre.', translation: 'Yüz yıl.' }] },
    { id: uuidv4(), term: 'tausend', type: 'other', translation: 'bin', examples: [{ sentence: 'Tausend Dank.', translation: 'Bin teşekkür.' }] },

    // Renkler
    { id: uuidv4(), term: 'rot', type: 'adjective', translation: 'kırmızı', examples: [{ sentence: 'Die Rose ist rot.', translation: 'Gül kırmızıdır.' }] },
    { id: uuidv4(), term: 'blau', type: 'adjective', translation: 'mavi', examples: [{ sentence: 'Der Himmel ist blau.', translation: 'Gökyüzü mavidir.' }] },
    { id: uuidv4(), term: 'grün', type: 'adjective', translation: 'yeşil', examples: [{ sentence: 'Das Gras ist grün.', translation: 'Çimen yeşildir.' }] },
    { id: uuidv4(), term: 'gelb', type: 'adjective', translation: 'sarı', examples: [{ sentence: 'Die Sonne ist gelb.', translation: 'Güneş sarıdır.' }] },
    { id: uuidv4(), term: 'schwarz', type: 'adjective', translation: 'siyah', examples: [{ sentence: 'Die Nacht ist schwarz.', translation: 'Gece siyahtır.' }] },
    { id: uuidv4(), term: 'weiß', type: 'adjective', translation: 'beyaz', examples: [{ sentence: 'Der Schnee ist weiß.', translation: 'Kar beyazdır.' }] },
    { id: uuidv4(), term: 'grau', type: 'adjective', translation: 'gri', examples: [{ sentence: 'Der Himmel ist grau.', translation: 'Gökyüzü gri.' }] },
    { id: uuidv4(), term: 'braun', type: 'adjective', translation: 'kahverengi', examples: [{ sentence: 'Der Bär ist braun.', translation: 'Ayı kahverengidir.' }] },

    // Mevsimler
    { id: uuidv4(), term: 'der Frühling', type: 'noun', translation: 'ilkbahar', details: 'Pl: die Frühlinge', examples: [{ sentence: 'Im Frühling blühen die Blumen.', translation: 'İlkbaharda çiçekler açar.' }] },
    { id: uuidv4(), term: 'der Sommer', type: 'noun', translation: 'yaz', details: 'Pl: die Sommer', examples: [{ sentence: 'Der Sommer ist heiß.', translation: 'Yaz sıcaktır.' }] },
    { id: uuidv4(), term: 'der Herbst', type: 'noun', translation: 'sonbahar', details: 'Pl: die Herbste', examples: [{ sentence: 'Im Herbst fallen die Blätter.', translation: 'Sonbaharda yapraklar düşer.' }] },
    { id: uuidv4(), term: 'der Winter', type: 'noun', translation: 'kış', details: 'Pl: die Winter', examples: [{ sentence: 'Der Winter ist kalt.', translation: 'Kış soğuktur.' }] },
  ]
};

// --- SET 3: TEMEL GRAMER ---
const grammarSet: StudySet = {
  id: 'grammar-basics-set-v3',
  title: 'Gramer Temelleri',
  description: 'Zamirler, edatlar ve bağlaçlar.',
  category: 'mixed',
  createdAt: new Date().toISOString(),
  progress: 0,
  cards: [
    // Zamirler
    { id: uuidv4(), term: 'ich', type: 'other', translation: 'ben', examples: [{ sentence: 'Ich bin hier.', translation: 'Ben buradayım.' }] },
    { id: uuidv4(), term: 'du', type: 'other', translation: 'sen', examples: [{ sentence: 'Wer bist du?', translation: 'Sen kimsin?' }] },
    { id: uuidv4(), term: 'er', type: 'other', translation: 'o (erkek)', examples: [{ sentence: 'Er ist mein Bruder.', translation: 'O benim erkek kardeşim.' }] },
    { id: uuidv4(), term: 'sie', type: 'other', translation: 'o (kadın) / onlar', examples: [{ sentence: 'Sie ist meine Schwester.', translation: 'O benim kız kardeşim.' }] },
    { id: uuidv4(), term: 'es', type: 'other', translation: 'o (nötr)', examples: [{ sentence: 'Es regnet.', translation: 'Yağmur yağıyor (O yağıyor).' }] },
    { id: uuidv4(), term: 'wir', type: 'other', translation: 'biz', examples: [{ sentence: 'Wir sind Freunde.', translation: 'Biz arkadaşız.' }] },
    { id: uuidv4(), term: 'ihr', type: 'other', translation: 'siz (çoğul)', examples: [{ sentence: 'Kommt ihr?', translation: 'Geliyor musunuz?' }] },
    { id: uuidv4(), term: 'Sie', type: 'other', translation: 'Siz (kibar)', examples: [{ sentence: 'Können Sie mir helfen?', translation: 'Bana yardım edebilir misiniz?' }] },
    { id: uuidv4(), term: 'mein', type: 'adjective', translation: 'benim', examples: [{ sentence: 'Das ist mein Buch.', translation: 'Bu benim kitabım.' }] },
    { id: uuidv4(), term: 'dein', type: 'adjective', translation: 'senin', examples: [{ sentence: 'Ist das dein Auto?', translation: 'Bu senin araban mı?' }] },

    // Edatlar
    { id: uuidv4(), term: 'mit', type: 'preposition', translation: 'ile', details: '+ Dativ', examples: [{ sentence: 'Ich komme mit dir.', translation: 'Seninle geliyorum.' }] },
    { id: uuidv4(), term: 'für', type: 'preposition', translation: 'için', details: '+ Akkusativ', examples: [{ sentence: 'Das ist für dich.', translation: 'Bu senin için.' }] },
    { id: uuidv4(), term: 'ohne', type: 'preposition', translation: 'sız/siz', details: '+ Akkusativ', examples: [{ sentence: 'Ohne dich gehe ich nicht.', translation: 'Sensiz gitmem.' }] },
    { id: uuidv4(), term: 'bei', type: 'preposition', translation: 'yanında/de/da', details: '+ Dativ', examples: [{ sentence: 'Ich bin bei Stefan.', translation: 'Stefan\'dayım.' }] },
    { id: uuidv4(), term: 'zu', type: 'preposition', translation: '-e/-a (yön)', details: '+ Dativ', examples: [{ sentence: 'Ich gehe zu Hause.', translation: 'Eve gidiyorum.' }] },
    { id: uuidv4(), term: 'von', type: 'preposition', translation: '-den/-dan', details: '+ Dativ', examples: [{ sentence: 'Das Geschenk ist von mir.', translation: 'Hediye benden.' }] },

    // Bağlaçlar
    { id: uuidv4(), term: 'und', type: 'conjunction', translation: 've', examples: [{ sentence: 'Ich und du.', translation: 'Ben ve sen.' }] },
    { id: uuidv4(), term: 'aber', type: 'conjunction', translation: 'ama', examples: [{ sentence: 'Klein aber fein.', translation: 'Küçük ama güzel.' }] },
    { id: uuidv4(), term: 'oder', type: 'conjunction', translation: 'veya', examples: [{ sentence: 'Kaffee oder Tee?', translation: 'Kahve mi çay mı?' }] },
    { id: uuidv4(), term: 'weil', type: 'conjunction', translation: 'çünkü', examples: [{ sentence: 'Ich esse, weil ich Hunger habe.', translation: 'Yiyorum çünkü açım.' }] },
    { id: uuidv4(), term: 'wenn', type: 'conjunction', translation: 'eğer/zaman', examples: [{ sentence: 'Wenn es regnet, bleibe ich zu Hause.', translation: 'Yağmur yağarsa evde kalırım.' }] },
    { id: uuidv4(), term: 'dass', type: 'conjunction', translation: '-dığı/-diği', examples: [{ sentence: 'Ich weiß, dass du kommst.', translation: 'Geleceğini biliyorum.' }] },
  ]
};

// --- SET 4: GÜNLÜK NESNELER ---
const objectsSet: StudySet = {
  id: 'daily-objects-set-v3',
  title: 'Günlük Nesneler',
  description: 'Evde, okulda ve işte sık kullanılan nesneler.',
  category: 'noun',
  createdAt: new Date().toISOString(),
  progress: 0,
  cards: [
    { id: uuidv4(), term: 'der Tisch', type: 'noun', translation: 'masa', details: 'Pl: die Tische', examples: [{ sentence: 'Das Essen steht auf dem Tisch.', translation: 'Yemek masada.' }] },
    { id: uuidv4(), term: 'der Stuhl', type: 'noun', translation: 'sandalye', details: 'Pl: die Stühle', examples: [{ sentence: 'Der Stuhl ist bequem.', translation: 'Sandalye rahat.' }] },
    { id: uuidv4(), term: 'das Buch', type: 'noun', translation: 'kitap', details: 'Pl: die Bücher', examples: [{ sentence: 'Ich lese ein Buch.', translation: 'Bir kitap okuyorum.' }] },
    { id: uuidv4(), term: 'das Handy', type: 'noun', translation: 'cep telefonu', details: 'Pl: die Handys', examples: [{ sentence: 'Mein Handy ist neu.', translation: 'Telefonum yeni.' }] },
    { id: uuidv4(), term: 'das Auto', type: 'noun', translation: 'araba', details: 'Pl: die Autos', examples: [{ sentence: 'Das Auto ist schnell.', translation: 'Araba hızlı.' }] },
    { id: uuidv4(), term: 'das Haus', type: 'noun', translation: 'ev', details: 'Pl: die Häuser', examples: [{ sentence: 'Das Haus ist groß.', translation: 'Ev büyük.' }] },
    { id: uuidv4(), term: 'die Tür', type: 'noun', translation: 'kapı', details: 'Pl: die Türen', examples: [{ sentence: 'Mach bitte die Tür zu.', translation: 'Lütfen kapıyı kapat.' }] },
    { id: uuidv4(), term: 'das Fenster', type: 'noun', translation: 'pencere', details: 'Pl: die Fenster', examples: [{ sentence: 'Das Fenster ist offen.', translation: 'Pencere açık.' }] },
    { id: uuidv4(), term: 'der Schlüssel', type: 'noun', translation: 'anahtar', details: 'Pl: die Schlüssel', examples: [{ sentence: 'Wo ist mein Schlüssel?', translation: 'Anahtarım nerede?' }] },
    { id: uuidv4(), term: 'die Tasche', type: 'noun', translation: 'çanta', details: 'Pl: die Taschen', examples: [{ sentence: 'Die Tasche ist schwer.', translation: 'Çanta ağır.' }] },
    { id: uuidv4(), term: 'das Wasser', type: 'noun', translation: 'su', details: 'Pl: -', examples: [{ sentence: 'Ich trinke Wasser.', translation: 'Su içiyorum.' }] },
    { id: uuidv4(), term: 'das Brot', type: 'noun', translation: 'ekmek', details: 'Pl: die Brote', examples: [{ sentence: 'Das Brot ist frisch.', translation: 'Ekmek taze.' }] },
  ]
};

// --- SET 5: SIFATLAR (TOP 20) ---
const adjectivesSet: StudySet = {
  id: 'adjectives-basics-set-v3',
  title: 'En Önemli 20 Sıfat',
  description: 'Almanca\'da en sık kullanılan sıfatlar ve zıt anlamlıları.',
  category: 'mixed',
  createdAt: new Date().toISOString(),
  progress: 0,
  cards: [
    { id: uuidv4(), term: 'gut', type: 'adjective', translation: 'iyi', details: 'Zıt: schlecht', examples: [{ sentence: 'Das ist eine gute Idee.', translation: 'Bu iyi bir fikir.' }] },
    { id: uuidv4(), term: 'schlecht', type: 'adjective', translation: 'kötü', details: 'Zıt: gut', examples: [{ sentence: 'Das Wetter ist schlecht.', translation: 'Hava kötü.' }] },
    { id: uuidv4(), term: 'groß', type: 'adjective', translation: 'büyük', details: 'Zıt: klein', examples: [{ sentence: 'Berlin ist eine große Stadt.', translation: 'Berlin büyük bir şehir.' }] },
    { id: uuidv4(), term: 'klein', type: 'adjective', translation: 'küçük', details: 'Zıt: groß', examples: [{ sentence: 'Das Haus ist klein.', translation: 'Ev küçük.' }] },
    { id: uuidv4(), term: 'neu', type: 'adjective', translation: 'yeni', details: 'Zıt: alt', examples: [{ sentence: 'Ich habe ein neues Auto.', translation: 'Yeni bir arabam var.' }] },
    { id: uuidv4(), term: 'alt', type: 'adjective', translation: 'eski/yaşlı', details: 'Zıt: neu/jung', examples: [{ sentence: 'Wie alt bist du?', translation: 'Kaç yaşındasın?' }] },
    { id: uuidv4(), term: 'jung', type: 'adjective', translation: 'genç', details: 'Zıt: alt', examples: [{ sentence: 'Er ist noch jung.', translation: 'O henüz genç.' }] },
    { id: uuidv4(), term: 'schön', type: 'adjective', translation: 'güzel', details: 'Zıt: hässlich', examples: [{ sentence: 'Das Leben ist schön.', translation: 'Hayat güzel.' }] },
    { id: uuidv4(), term: 'wichtig', type: 'adjective', translation: 'önemli', details: '', examples: [{ sentence: 'Das ist sehr wichtig.', translation: 'Bu çok önemli.' }] },
    { id: uuidv4(), term: 'richtig', type: 'adjective', translation: 'doğru', details: 'Zıt: falsch', examples: [{ sentence: 'Das ist richtig.', translation: 'Bu doğru.' }] },
    { id: uuidv4(), term: 'falsch', type: 'adjective', translation: 'yanlış', details: 'Zıt: richtig', examples: [{ sentence: 'Die Antwort ist falsch.', translation: 'Cevap yanlış.' }] },
    { id: uuidv4(), term: 'einfach', type: 'adjective', translation: 'kolay/basit', details: 'Zıt: schwer', examples: [{ sentence: 'Deutsch ist nicht einfach.', translation: 'Almanca kolay değil.' }] },
    { id: uuidv4(), term: 'schwer', type: 'adjective', translation: 'zor/ağır', details: 'Zıt: einfach/leicht', examples: [{ sentence: 'Die Tasche ist schwer.', translation: 'Çanta ağır.' }] },
    { id: uuidv4(), term: 'schnell', type: 'adjective', translation: 'hızlı', details: 'Zıt: langsam', examples: [{ sentence: 'Bitte fahr nicht so schnell.', translation: 'Lütfen o kadar hızlı sürme.' }] },
    { id: uuidv4(), term: 'langsam', type: 'adjective', translation: 'yavaş', details: 'Zıt: schnell', examples: [{ sentence: 'Sprich bitte langsam.', translation: 'Lütfen yavaş konuş.' }] },
    { id: uuidv4(), term: 'laut', type: 'adjective', translation: 'yüksek sesli/gürültülü', details: 'Zıt: leise', examples: [{ sentence: 'Die Musik ist zu laut.', translation: 'Müzik çok yüksek sesli.' }] },
    { id: uuidv4(), term: 'leise', type: 'adjective', translation: 'sessiz', details: 'Zıt: laut', examples: [{ sentence: 'Sei bitte leise.', translation: 'Lütfen sessiz ol.' }] },
    { id: uuidv4(), term: 'teuer', type: 'adjective', translation: 'pahalı', details: 'Zıt: billig', examples: [{ sentence: 'Das Auto ist zu teuer.', translation: 'Araba çok pahalı.' }] },
    { id: uuidv4(), term: 'billig', type: 'adjective', translation: 'ucuz', details: 'Zıt: teuer', examples: [{ sentence: 'Ist das billig?', translation: 'Bu ucuz mu?' }] },
    { id: uuidv4(), term: 'kalt', type: 'adjective', translation: 'soğuk', details: 'Zıt: warm/heiß', examples: [{ sentence: 'Mir ist kalt.', translation: 'Üşüyorum (Bana soğuk).' }] },
  ]
};

export const mockSets: StudySet[] = [
  topVerbsSet,
  vocabSet,
  grammarSet,
  objectsSet,
  adjectivesSet
];
